from pathlib import Path
from zipfile import ZipFile
from lxml import etree
from pptx import Presentation
import fitz,json
r=Path(__file__).parent;meta=json.loads((r/'content.json').read_text());n=len(meta);main=19
p=Presentation(r/'Sanich6_Management_v2.pptx');assert len(p.slides)==n==24
assert all(s.has_notes_slide for s in p.slides)
assert all(sh.left>=0 and sh.top>=0 and sh.left+sh.width<=p.slide_width+20000 and sh.top+sh.height<=p.slide_height+20000 for s in p.slides for sh in s.shapes)
ns={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','p159':'http://schemas.microsoft.com/office/powerpoint/2015/09/main'}
with ZipFile(r/'Sanich6_Management_v2.pptx') as z:
 assert z.testzip() is None
 for i in range(1,n+1):
  root=etree.fromstring(z.read(f'ppt/slides/slide{i}.xml'));assert root.xpath('count(.//p159:morph)',namespaces=ns)==(1 if i<=main else 0);assert root.xpath('count(.//p:fade)',namespaces=ns)==1
pdf=fitz.open(r/'Sanich6_Management_v2.pdf');assert len(pdf)==n
for i,page in enumerate(pdf):
 blocks=page.get_text('blocks');assert blocks
 assert all(b[0]>=-1 and b[1]>=-1 and b[2]<=page.rect.width+1 and b[3]<=page.rect.height+1 for b in blocks),(i,'text outside slide')
text=''.join(p.get_text() for p in pdf);assert '3 месяца' in text and 'качеств' in text.lower()
(r/'PRESENTATION_VALIDATION.txt').write_text(f'PASS: {n} PowerPoint slides ({main} main + {n-main} appendix); notes on every slide; shapes within canvas; valid archive/XML; Morph on main slides with Fade fallback; Fade on appendix.\nPASS: actual LibreOffice export produces {n} PDF pages; no extracted text outside slide. Source attribution and 3-month development statement included.\nNOT TESTED: animation playback in Microsoft PowerPoint, presentation computer and projector.\n')
print('Validated',n,'slides and matching PDF')
