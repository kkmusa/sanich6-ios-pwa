from pathlib import Path
from openpyxl import load_workbook
import math,subprocess
r=Path(__file__).parent;src=r/'Sanich6_Business_Case_v2.xlsx';inp=Path('/tmp/sanich-finance-in');out=Path('/tmp/sanich-finance-out')
for name in ['blank','valid','zero','unknown_frequency']:
 w=load_workbook(src)
 if name!='blank':
  t=w['Ресурс времени'];e=w['Событие'];c=w['Окупаемость']
  for cell,val in {'B5':10,'B6':100,'B7':8,'B8':2,'B9':1,'B10':600,'B11':50,'B12':100}.items():t[cell]=val
  for cell,val in {'B4':24,'B5':10,'B6':1000,'B7':50,'B8':5000,'B9':20,'B10':20,'B11':50}.items():e[cell]=val
  for cell,val in {'B4':10000,'B5':1000,'B6':2000}.items():c[cell]=val
  if name=='zero':t['B11']=0;e['B10']=0
  if name=='unknown_frequency':e['B9']=None
 w.save(inp/(name+'.xlsx'))
subprocess.run(['soffice','-env:UserInstallation=file:///tmp/sanich-finance-lo-v2','--headless','--convert-to','xlsx','--outdir',str(out),*[str(inp/(n+'.xlsx')) for n in ['blank','valid','zero','unknown_frequency']]],check=True,capture_output=True,text=True)
def value(name,sheet,cell):return load_workbook(out/(name+'.xlsx'),data_only=True)[sheet][cell].value
def equal(name,s,c,v):
 a=value(name,s,c)
 if isinstance(v,(int,float)):assert isinstance(a,(int,float)) and math.isclose(a,v,rel_tol=1e-9),(name,s,c,a,v)
 else:assert a==v,(name,s,c,a,v)
for s,c in [('Ресурс времени','B18'),('Событие','B18'),('Окупаемость','B12'),('Окупаемость','B13')]:assert value('blank',s,c) in [None,'']
for s,c,v in [('Ресурс времени','B15',8000),('Ресурс времени','B16',8000/60),('Ресурс времени','B18',40000),('Событие','B14',10),('Событие','B16',10000),('Событие','B17',2),('Событие','B18',20000),('Окупаемость','B9',24000),('Окупаемость','B12',36000),('Окупаемость','B13',3),('Окупаемость','B14',10000/(5000-1000-2000/12))]:equal('valid',s,c,v)
equal('zero','Окупаемость','B12',-24000);equal('zero','Окупаемость','B14','Не достигается')
assert value('unknown_frequency','Окупаемость','B12') in [None,'']
equal('unknown_frequency','Окупаемость','B13',3)
print('PASS: real spreadsheet recalculation via LibreOffice. Blank inputs; time resource; event cost; expected annual effect; first-year net; break-even; zero benefit; unknown event frequency. Test values are synthetic and not company data.')
