from pathlib import Path
import json,base64
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from lxml import etree
from fontTools.ttLib import TTFont
from fontTools.pens.basePen import BasePen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.reverseContourPen import ReverseContourPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
R=Path(__file__).parent;A=R/'assets/oilfield_illustration.png';W,H=1280,720
P=Presentation();P.slide_width=Inches(13.333333);P.slide_height=Inches(7.5)
N={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main','mc':'http://schemas.openxmlformats.org/markup-compatibility/2006','p159':'http://schemas.microsoft.com/office/powerpoint/2015/09/main','p14':'http://schemas.microsoft.com/office/powerpoint/2010/main'}
def u(v):return Inches(v/96)
def tx(s,x,y,w,h,t,size,c='FFFFFF',name='text'):
 q=s.shapes.add_textbox(u(x),u(y),u(w),u(h));q.name=name;q.text_frame.word_wrap=True;q.text_frame.margin_left=q.text_frame.margin_right=q.text_frame.margin_top=q.text_frame.margin_bottom=0
 for i,l in enumerate(t.split('\n')):
  p=q.text_frame.paragraphs[0] if i==0 else q.text_frame.add_paragraph();p.text=l;p.font.name='Arial';p.font.bold=True;p.font.size=Pt(size*.75);p.font.color.rgb=RGBColor.from_string(c);p.space_after=Pt(10)
 return q
def rect(s,x,y,w,h,c,name):
 q=s.shapes.add_shape(MSO_SHAPE.RECTANGLE,u(x),u(y),u(w),u(h));q.name=name;q.fill.solid();q.fill.fore_color.rgb=RGBColor.from_string(c);q.line.fill.background();return q
font=TTFont('/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf');gs=font.getGlyphSet();cm=font.getBestCmap();glyphs=[];bound=[];off=0
svg=SVGPathPen(gs)
for ch in 'САНЫЧ-6':
 g=gs[cm[ord(ch)]];bp=BoundsPen(gs);g.draw(bp)
 if bp.bounds:
  b=bp.bounds;bound.append((b[0]+off,b[1],b[2]+off,b[3]));glyphs.append((g,off));g.draw(TransformPen(svg,(1,0,0,1,off,0)))
 off+=g.width
xmin=min(b[0] for b in bound);xmax=max(b[2] for b in bound);ymin=min(b[1] for b in bound);ymax=max(b[3] for b in bound)
# Anchor inside the left stem of Н; magnifying the hole reveals the stationary photograph.
g,off=glyphs[2];bp=BoundsPen(gs);g.draw(bp);gx=off+bp.bounds[0]+110
anchor=[70+(gx-xmin)/(xmax-xmin)*1140,350]
zoom=55;states=[{'image':[0,0,1280,720],'mask':[0,0,1280,720]}, {'image':[0,0,1280,720],'mask':[640-anchor[0]*zoom,360-anchor[1]*zoom,1280*zoom,720*zoom]}, {'image':[650,100,570,510],'mask':[640-anchor[0]*zoom,360-anchor[1]*zoom,1280*zoom,720*zoom]}]
for i,z in enumerate(states):
 s=P.slides.add_slide(P.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor.from_string('000000')
 x,y,w,h=z['image'];q=s.shapes.add_picture(str(A),u(x),u(y),width=u(w),height=u(h));q.name='!!OilfieldImage'
 from PIL import Image
 iw,ih=Image.open(A).size
 if iw/ih>w/h:
  q.crop_left=(1-(w/h)/(iw/ih))*(1 if i==2 else .5);q.crop_right=0 if i==2 else q.crop_left
 else:q.crop_top=q.crop_bottom=(1-(iw/ih)/(w/h))/2
 x,y,w,h=z['mask'];q=rect(s,x,y,w,h,'000000','!!WordAperture');sp=q._element.find('p:spPr',N);sp.remove(sp.find('a:prstGeom',N));cg=etree.SubElement(sp,'{'+N['a']+'}custGeom')
 for tag in ['avLst','gdLst','ahLst','cxnLst']:etree.SubElement(cg,'{'+N['a']+'}'+tag)
 etree.SubElement(cg,'{'+N['a']+'}rect',l='0',t='0',r='w',b='h');pl=etree.SubElement(cg,'{'+N['a']+'}pathLst');path=etree.SubElement(pl,'{'+N['a']+'}path',w='128000',h='72000',fill='norm',stroke='false')
 def pt(e,x,y):etree.SubElement(e,'{'+N['a']+'}pt',x=str(round(x*100)),y=str(round(y*100)))
 pt(etree.SubElement(path,'{'+N['a']+'}moveTo'),0,0)
 for x,y in [(1280,0),(1280,720),(0,720)]:pt(etree.SubElement(path,'{'+N['a']+'}lnTo'),x,y)
 etree.SubElement(path,'{'+N['a']+'}close')
 class Pen(BasePen):
  def point(self,e,p):pt(e,70+(p[0]+self.offset-xmin)/(xmax-xmin)*1140,250+(ymax-p[1])/(ymax-ymin)*200)
  def _moveTo(self,p):self.point(etree.SubElement(path,'{'+N['a']+'}moveTo'),p)
  def _lineTo(self,p):self.point(etree.SubElement(path,'{'+N['a']+'}lnTo'),p)
  def _curveToOne(self,a,b,c):
   e=etree.SubElement(path,'{'+N['a']+'}cubicBezTo')
   for p in [a,b,c]:self.point(e,p)
  def _closePath(self):etree.SubElement(path,'{'+N['a']+'}close')
 pen=Pen(gs)
 for g,offset in glyphs:pen.offset=offset;g.draw(ReverseContourPen(pen))
 # Fine contour keeps the dark parts of the image-filled word legible.
 import copy
 outline=etree.SubElement(pl,'{'+N['a']+'}path',w='128000',h='72000',fill='none',stroke='true')
 for node in list(path)[5:]:outline.append(copy.deepcopy(node))
 q.line.color.rgb=RGBColor.from_string('8C7950');q.line.width=Pt(.55)

 rect(s,70,62,86 if i<2 else 510,5,'FFCD00','!!YellowRule')
 if i==0:
  tx(s,70,88,1140,45,'ПРОЕКТ ЦИФРОВОГО ПОМОЩНИКА',20,'FFCD00','IntroEyebrow')
  tx(s,73,555,1130,60,'ОПЕРАТОРУ ДОБЫЧИ НЕФТИ И ГАЗА',24,'FFFFFF','IntroCaption')
 elif i==1:
  tx(s,70,145,680,85,'САНЫЧ-6',76,'FFFFFF','!!ProductTitle')
  tx(s,74,285,660,220,'Рабочие инструменты.\nВсегда рядом.',52,'FFCD00','!!ProductSubtitle')
 else:
  tx(s,70,100,520,80,'САНЫЧ-6',64,'FFFFFF','!!ProductTitle')
  tx(s,74,235,520,160,'Цель проекта',52,'FFCD00','!!ProductSubtitle')
  tx(s,76,365,510,180,'Упростить доступ оператора\nк расчётам и рабочим\nматериалам на месте работы.',29,'FFFFFF','Goal')
 tx(s,72,666,1140,30,'ООО «РН-Юганскнефтегаз» · концепция оформления',14,'FFFFFF','!!Footer')
 ac=etree.Element('{'+N['mc']+'}AlternateContent',nsmap=N);ch=etree.SubElement(ac,'{'+N['mc']+'}Choice',Requires='p159');tr=etree.SubElement(ch,'{'+N['p']+'}transition',advClick='1',spd='slow');tr.set('{'+N['p14']+'}dur','1800');etree.SubElement(tr,'{'+N['p159']+'}morph',option='byObject');fb=etree.SubElement(ac,'{'+N['mc']+'}Fallback');tr=etree.SubElement(fb,'{'+N['p']+'}transition',advClick='1',spd='slow');etree.SubElement(tr,'{'+N['p']+'}push',dir='l');s._element.insert(2,ac)
 s.notes_slide.notes_text_frame.text='Три кадра проверки вступления по референсу «Марс». Чёрный, белый, жёлтый; не утверждённый корпоративный шаблон. Изображение сгенерировано для иллюстрации, не фотография объекта компании. WordAperture — редактируемая векторная фигура с отверстиями по буквам. Для движения нужен Morph; запасной Push имеет другое поведение. Воспроизведение в Microsoft PowerPoint здесь не испытано.'
P.save(R/'Sanich6_RN_Opening.pptx')
data={'states':states,'anchor':anchor,'zoom':zoom,'glyph_bounds':[xmin,ymin,xmax,ymax],'word_path':svg.getCommands(),'image':base64.b64encode(A.read_bytes()).decode()}
(R/'render_data.json').write_text(json.dumps(data));print('Three-frame opening built; anchor',anchor)
