from pathlib import Path
from pptx import Presentation
from docx import Document
from docx.shared import Pt,RGBColor
from PIL import Image,ImageDraw
import json,fitz,hashlib,zipfile
R=Path(__file__).parent;P=Presentation(R/'OperatorDNG_Working_Presentation.pptx');D=fitz.open(R/'OperatorDNG_Working_Presentation.pdf');meta=json.loads((R/'SCENES.json').read_text())
headings=['Открытие','Представление продукта','Цель проекта','Четыре согласованные задачи','Обзор инструментов','Ручной замер','Пример расчёта дебита','Замер через полночь','Охлаждение ПЭД','Пять станций управления','Разгон','РИЧ','Регламент ВНР','Поиск и закладки','Другие рабочие инструменты','Материальная основа','Три месяца разработки','Потенциальная аудитория','Оценка пользы','Предложение пилота','Завершение','Автор проекта — запасной','Расчёты и ограничения — запасной']
doc=Document();doc.add_heading('Оператор ДНГ',0);doc.add_paragraph('Заметки для выступления · рабочая версия');doc.add_paragraph('Ориентир: 8–10 минут. Первые три слайда — согласованное вступление. Дайте переходам завершиться. Данные автора и портрет ещё не предоставлены; запасные слайды скрыты.');md=['# Оператор ДНГ — заметки для выступления\n']
for i,(h,s) in enumerate(zip(headings,P.slides)):
 title=f'{i+1:02d}. {h}';doc.add_heading(title,1)
 for para in s.notes_slide.notes_text_frame.text.split('\n'):doc.add_paragraph(para)
 md.append('\n## '+title+'\n\n'+s.notes_slide.notes_text_frame.text)
doc.styles['Normal'].font.name='Arial';doc.styles['Normal'].font.size=Pt(11)
for name,size in [('Title',26),('Heading 1',16)]:
 doc.styles[name].font.name='Arial';doc.styles[name].font.size=Pt(size);doc.styles[name].font.color.rgb=RGBColor(0,0,0)
doc.save(R/'OperatorDNG_Speaker_Notes.docx');(R/'SPEAKER_NOTES_RU.md').write_text('\n'.join(md),encoding='utf-8')
# Review contact sheets: final PDF, not intermediate renders.
for base in range(0,len(D),6):
 canvas=Image.new('RGB',(1440,1260),'#363636');dr=ImageDraw.Draw(canvas)
 for j,i in enumerate(range(base,min(base+6,len(D)))):
  pg=D[i];px=pg.get_pixmap(matrix=fitz.Matrix(720/pg.rect.width,720/pg.rect.width));im=Image.frombytes('RGB',[px.width,px.height],px.samples);x=j%2*720;y=j//2*420;canvas.paste(im,(x,y));dr.text((x+10,y+406),str(i+1),fill='white')
 canvas.save(R/f'Overview_{base//6+1}.jpg')
(R/'README_RU.md').write_text('''# Оператор ДНГ — рабочая презентация

21 основной слайд, 2 скрытых запасных. Утверждённое вступление по референсу «Марс» сохранено. Чёрный, белый, жёлтый #FFCD00. Четыре задачи взяты из согласованного текста; полные пояснения находятся в заметках и отдельном Word-файле.

## Как открыть
Открыть OperatorDNG_Working_Presentation.pptx в Microsoft PowerPoint. «Показ слайдов → С начала». Листать щелчком или стрелкой. В PDF, Quick Look и предпросмотре GitHub анимации нет. Для скачивания с GitHub нажать Download raw file (стрелка вниз) после входа в свой аккаунт.

Для запланированного движения нужен PowerPoint с поддержкой «Трансформация / Morph». Для старого Office предусмотрен запасной сдвиг Push; он не воспроизводит эффект буквенной маски. Воспроизведение в настоящем Microsoft PowerPoint здесь не проверено.

## Навигация
На слайде 5 четыре карточки открывают свои разделы. В разделах сверху справа — «Все инструменты». На изображении ручного замера и регламента можно нажать для перехода к увеличенному фрагменту и обратно. Всего проверено 26 внутренних действий.

## Что входит
- PowerPoint — редактируемый файл, включая текст, карточки, векторную маску и переходы.
- PDF — 21 страница основного показа, без анимации.
- OperatorDNG_Speaker_Notes.docx — заметки для выступления на русском языке.
- OperatorDNG_Business_Case.xlsx — модель оценки эффекта. Неизвестные значения нужно подтвердить; вымышленные ставки и суммы не подставлялись. 17 исходных формул сохранены.
- Opening_Preview.mp4 — только 11-секундный независимый аниматик вступления, не запись PowerPoint и не видео всей презентации.
- VALIDATION.json — результаты доступных проверок.
- Исходники построения и материалы для воспроизводимости.

Фото автора, точные ФИО, должность и цех не предоставлены. Под них оставлен скрытый слайд 22; в основной показ заполнитель не попадает. Показ слайдов заканчивается на слайде 21.

## Достоверность
Промысловое изображение создано для оформления; это иллюстрация, не фотография объекта компании. Фотография станции взята из Android-проекта, её значения не являются рекомендуемыми настройками. Скриншоты PWA реальные; внутри презентации это изображения, не интерактивные расчётные формы. Официальный логотип компании не подставлялся; корпоративное утверждение проекта не заявляется.

Три месяца, минимальные прямые денежные расходы и потенциальная аудитория около 250 человек — сведения автора. Частота 7–9 замеров относится к отдельным дням по его опыту, не ко всем сотрудникам. Снижение риска ошибок — ожидаемый эффект для проверки пилотом, не доказанный результат внедрения. Цены ремонтов и суммы сохранённой добычи не выдумывались.

ВНР и документы ПБ и ОТ в пяти томах разделены. Полнота интеграции всех томов и актуальность редакций не подтверждены. RosPump не представлен как интегрированная система. Приложение не управляет оборудованием и не заменяет действующие инструкции.

Проверены структура PPTX, имена объектов, цели внутренних переходов, сохранение согласованных задач и геометрии вступления, изменение размеров карточек и кадрирования, примеры расчётов, экспорт PDF и отсутствие обрезанного текста/наложений отдельных текстовых блоков. Основные слайды просмотрены в экспорте LibreOffice. Реальный iPhone, Android и проигрыватель Microsoft PowerPoint этой работой не испытаны.
''',encoding='utf-8')
files=['OperatorDNG_Working_Presentation.pptx','OperatorDNG_Working_Presentation.pdf','OperatorDNG_Speaker_Notes.docx','OperatorDNG_Business_Case.xlsx','Opening_Preview.mp4']
(R/'DELIVERY.json').write_text(json.dumps({f:{'bytes':(R/f).stat().st_size,'sha256':hashlib.sha256((R/f).read_bytes()).hexdigest()} for f in files},indent=2))
out=Path('/workspace/artifacts/OperatorDNG_Working_Presentation_Complete.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for f in R.rglob('*'):
  if f.is_file() and not f.name.startswith('Review_') and not f.name.startswith('.~') and f.suffix in ['.pptx','.pdf','.docx','.xlsx','.mp4','.py','.json','.md','.jpg','.png']:z.write(f,'OperatorDNG_Working_Presentation/'+str(f.relative_to(R)))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print('Packaged',out.stat().st_size,'bytes')
