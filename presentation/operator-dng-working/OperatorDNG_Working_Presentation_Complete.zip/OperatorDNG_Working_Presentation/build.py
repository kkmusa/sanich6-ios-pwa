from pathlib import Path
import json,copy
from PIL import Image
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from lxml import etree
R=Path(__file__).parent;A=R/'assets';P=Presentation(R/'Approved_Opening.pptx');Y='FFCD00';B='000000';W='FFFFFF';M='B7B7B7'
N={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main','mc':'http://schemas.openxmlformats.org/markup-compatibility/2006','p159':'http://schemas.microsoft.com/office/powerpoint/2015/09/main','p14':'http://schemas.microsoft.com/office/powerpoint/2010/main'}
def u(n):return Inches(n/96)
def tx(s,x,y,w,h,t,z=30,c=W,bold=False,name=None):
 q=s.shapes.add_textbox(u(x),u(y),u(w),u(h));q.name=name or 'Text_'+str(len(s.shapes));tf=q.text_frame;tf.word_wrap=True
 tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
 for i,line in enumerate(t.split('\n')):
  p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=line;p.font.name='Arial';p.font.size=Pt(z*.75);p.font.bold=bold;p.font.color.rgb=RGBColor.from_string(c);p.space_after=Pt(7);p.line_spacing=1.04
 return q
def rect(s,x,y,w,h,c,name=None,radius=False):
 q=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,u(x),u(y),u(w),u(h));q.name=name or 'Block_'+str(len(s.shapes));q.fill.solid();q.fill.fore_color.rgb=RGBColor.from_string(c);q.line.fill.background()
 style=q._element.find('p:style',N)
 if style is not None:q._element.remove(style)
 if radius:q.adjustments[0]=.035
 return q
def pic(s,a,x,y,w,h,name,crop=None,focus=.5):
 q=s.shapes.add_picture(str(A/a),u(x),u(y),width=u(w),height=u(h));q.name=name
 if crop:q.crop_left,q.crop_top,q.crop_right,q.crop_bottom=crop
 else:
  iw,ih=Image.open(A/a).size
  if iw/ih>w/h:
   cut=1-(w/h)/(iw/ih);q.crop_left=cut*focus;q.crop_right=cut*(1-focus)
  else:q.crop_top=q.crop_bottom=(1-(iw/ih)/(w/h))/2
 return q
def morph(s,ms=1400,hidden=False):
 if hidden:
  t=etree.Element('{'+N['p']+'}transition',advClick='1');etree.SubElement(t,'{'+N['p']+'}fade');s._element.insert(2,t);return
 a=etree.Element('{'+N['mc']+'}AlternateContent',nsmap=N);ch=etree.SubElement(a,'{'+N['mc']+'}Choice',Requires='p159');t=etree.SubElement(ch,'{'+N['p']+'}transition',advClick='1',spd='slow');t.set('{'+N['p14']+'}dur',str(ms));etree.SubElement(t,'{'+N['p159']+'}morph',option='byObject');fb=etree.SubElement(a,'{'+N['mc']+'}Fallback');t=etree.SubElement(fb,'{'+N['p']+'}transition',advClick='1',spd='slow');etree.SubElement(t,'{'+N['p']+'}push',dir='l');s._element.insert(2,a)
def chrome(s,i,section,light=False):
 c=B if light else W
 rect(s,70,62,1140,4,Y if not light else B,'!!Rule')
 tx(s,72,87,1080,28,'ОПЕРАТОР ДНГ / '+section,16,c,True,'!!Section')
 tx(s,72,670,1060,25,'ООО «РН-Юганскнефтегаз» · проект для обсуждения',13,c,False,'!!Footer')
 tx(s,1165,670,55,25,f'{i:02d}',13,c,name='SlideNumber')
def title(s,t,sub='',w=650,z=57,suby=355):
 tx(s,72,155,w,170,t,z,W,True,'!!Headline')
 if sub:tx(s,76,suby,w,160,sub,27,M,name='!!Subtitle')
def rows(s,items,x=76,y=465,w=620,z=24,step=55):
 for j,t in enumerate(items):rect(s,x,y+j*step+7,4,24,Y);tx(s,x+22,y+j*step,w,50,t,z,W,name=f'Row{j}')
TASKS=[
('Объединить рабочие инструменты','собрать расчёты, инструкции и справочные материалы в одном приложении.'),
('Упростить ежедневные расчёты и замеры','автоматизировать вычисления, отсчёт времени и сохранение результатов.'),
('Помочь соблюдать последовательность действий','предоставить инструкции и фотографии для конкретных моделей станций управления.'),
('Обеспечить быстрый доступ к информации на промысле','реализовать поиск, закладки и работу предварительно загруженных материалов без интернета.')]
LABELS=['Ручной\nзамер','Охлаждение\nПЭД','Разгон\nи РИЧ','Регламент\nВНР'];ASSETS=['manual','ped','ramp','vnr'];GEOM=[]
def panels(s,state=None,rich=False):
 current=[]
 for j,(label,asset) in enumerate(zip(LABELS,ASSETS)):
  if state=='hub':
   x,y,w,h=70+j*290,150,270,490;ix,iy,iw,ih=x+53,y+125,164,355;crop=[0,0,0,0];titlez=29
  elif state=='manual' and j==0:
   x,y,w,h=70,150,745,490;ix,iy,iw,ih=565,190,190,411;crop=[0,0,0,0];titlez=0
  elif state=='manual':
   x,y,w,h=835+(j-1)*130,150,115,490;ix,iy,iw,ih=x+8,310,99,214;crop=[0,0,0,0];titlez=16
  elif state=='result' and j==0:
   x,y,w,h=650,160,560,425;ix,iy,iw,ih=672,180,516,385;crop=[0,.23,0,.36];titlez=0
  elif state=='vnr_macro' and j==3:
   x,y,w,h=650,170,560,430;ix,iy,iw,ih=673,192,514,385;crop=[0,0,0,.62];titlez=0
  elif state in ['cooling','ramp','rich','vnr'] and j=={'cooling':1,'ramp':2,'rich':2,'vnr':3}[state]:
   x,y,w,h=790,150,420,490;ix,iy,iw,ih=892,183,195,422;crop=[0,0,0,0];titlez=0
  else:
   x,y,w,h=1400+j*290,150,270,490;ix,iy,iw,ih=x+53,y+125,164,355;crop=[0,0,0,0];titlez=0
  rect(s,x,y,w,h,W,f'!!Panel{j}',True)
  pic(s,('rich' if rich and j==2 else asset)+'.png',ix,iy,iw,ih,f'!!PanelImage{j}',crop)
  if titlez:tx(s,x+20,y+19,w-40,100,(['Замер','ПЭД','Станции','ВНР'][j] if state=='manual' else label),titlez,B,True,f'!!PanelTitle{j}')
  else:tx(s,x+10,y+8,w-20,25,'',14,B,name=f'!!PanelTitle{j}')
  current.append([x,y,w,h,ix,iy,iw,ih,*crop])
 GEOM.append(current)
SCENES=[('tasks','ЗАДАЧИ'),('hub','ВОЗМОЖНОСТИ'),('manual','РУЧНОЙ ЗАМЕР'),('result','РУЧНОЙ ЗАМЕР'),('interval','ВРЕМЕННОЙ ИНТЕРВАЛ'),('cooling','ОХЛАЖДЕНИЕ ПЭД'),('stations','СТАНЦИИ УПРАВЛЕНИЯ'),('ramp','РАЗГОН'),('rich','РИЧ'),('vnr','РЕГЛАМЕНТ ВНР'),('vnr_macro','РЕГЛАМЕНТ ВНР'),('tools','РАБОЧИЙ НАБОР'),('sources','ОСНОВА ПРОЕКТА'),('development','РАЗРАБОТКА'),('audience','МАСШТАБ'),('effects','ОЦЕНКА ПОЛЬЗЫ'),('pilot','ПРЕДЛОЖЕНИЕ'),('closing','ОПЕРАТОР ДНГ'),('author','АВТОР / ЗАПАСНОЙ'),('reference','ВОПРОСЫ / ЗАПАСНОЙ')]
NOTES={
 'tasks':'Четыре задачи согласованы автором. Сохранять формулировки без добавления пятой.\n'+'\n'.join(f'{i+1}. {a} — {b}' for i,(a,b) in enumerate(TASKS)),
 'hub':'Показать приложение целиком. Четыре карточки — разные рабочие ситуации, а не весь перечень функций. На карточки можно нажать для открытия раздела. Для последовательного выступления достаточно листать дальше.',
 'manual':'По опыту автора в отдельные дни бывает семь–девять ручных замеров. Это не средняя нагрузка всех 250 человек. Оператор запускает таймер, затем вводит объём. Приложение сохраняет корректный результат автоматически и восстанавливает состояние замера при возвращении на устройстве. Это не системное плавающее окно поверх других приложений.',
 'result':'Математический пример: 100 литров за 60 секунд дают 144 м³/сут. Формула Q=86,4×V/t, где объём в литрах, время в секундах. Это не фактический дебит конкретной скважины.',
 'interval':'Математический пример: 23:50 до 00:10 следующей даты — 20 минут, то есть 1200 секунд. При 100 литрах Q=7,2 м³/сут. Даты начала и окончания выбираются отдельно. Показать пользу при переходе через полночь.',
 'cooling':'При выводе на режим важно учитывать условия охлаждения двигателя и корректность исходных данных. Приложение помогает выполнить предусмотренный расчёт. Не утверждать гарантированное предотвращение отказов. Обязательность и периодичность конкретных расчётов сверяют профильные специалисты по действующим документам.',
 'stations':'В проекте доступны материалы пяти моделей станций. Фотография КАСКАД-НТ взята из Android-эталона, значения на ней не являются рекомендуемыми настройками. Не смешивать инструкции разных моделей.',
 'ramp':'Автор описывает риск слишком быстрого разгона и роста количества взвешенных частиц, а также износа рабочих органов УЭЦН. Это рабочий сценарий для проверки технологами, не универсальная доказанная причинность. Показать доступ к порядку действий для выбранного оборудования. Приложение не управляет станцией.',
 'rich':'Неправильный порядок переключений может стать источником нежелательного режима по описанному автором сценарию. Последовательность нужно проверять для конкретной модели и редакции инструкции. Приложение предоставляет материалы, а действия контролирует персонал. Оно не блокирует ошибочные команды.',
 'vnr':'В проекте восстановлены 207 страниц документа ВНР. Полный офлайн после предварительной загрузки. Поиск, внутренние ссылки и закладки. Допустимость распространения и актуальность документа проверяют перед официальным внедрением.',
 'vnr_macro':'Показать поиск, переходы и закладки. Изображение является настоящим скриншотом PWA, внутри PowerPoint это иллюстрация, не работающая форма. История и закладки сохраняются локально на устройстве.',
 'tools':'Другие инструменты включают расчёт уровня, необходимой частоты, притока, потенциала, РПД, коэффициента двигателя 2А и отпайки. При расчёте отпайки учитываются предусмотренные исходники питания, ПЭД, кабеля и вариант ЧРП. Это помощь в расчёте, не автоматическое назначение уставки. Электронный уровень в эту работу не входит.',
 'sources':'Android — функциональный эталон формул и данных. Регламент ВНР отдельно от названных автором документов ПБ и ОТ в пяти томах. Название со слов автора: «Инструкции по промышленной безопасности и охране труда для работников структурных подразделений ООО „РН-Юганскнефтегаз“». Полноту интеграции всех томов и актуальность редакций не утверждать. Предоставленные учебные материалы RosPump и «Качество данных» использованы как контекст, интеграции с этими системами нет.',
 'development':'Три календарных месяца по данным автора. Прямые денежные расходы минимальны по его оценке. Основной вклад — время. Не называть труд бесплатным и не превращать календарный срок в человеко-месяцы. Проверка, внедрение и сопровождение имеют отдельные затраты.',
 'audience':'Около 250 — оценка потенциальной аудитории, не число активных пользователей. У опытных работников и новичков разные задачи; общая точка — доступ к рабочим инструментам. Масштабирование предлагается после пилота.',
 'effects':'Пользу предлагается измерять в сопоставимых заданиях: время выполнения, корректность расчёта и последовательности, доступность материалов без сети. Снижение риска ошибок — ожидаемый эффект для проверки. Не заявлять уже предотвращённые ремонты или сохранённую добычу. Финансовые ставки и частота событий пока не подтверждены.',
 'pilot':'Пилот — отдельное предложение руководству, не пятая задача проекта. Начать с проверки формул, материалов и редакций ответственными специалистами. Определить группу, задания и показатели. Затем принять решение по измеренным результатам.',
 'closing':'Закончить конкретным предложением: согласовать профильную проверку и ограниченный пилот. Дать аудитории время на вопросы. Не представлять приложение как уже утверждённое корпоративное решение.',
 'author':'Запасной скрытый слайд. Фото, ФИО, точная должность и номер цеха ещё не предоставлены. Не подставлять вымышленную личность.',
 'reference':'Ранее сохранённый отчёт PWA v3: 58 локальных тестов, 479 эталонных численных примеров и 6 проверок готовой сборки. Эти данные не подтверждают реальные испытания iPhone/Safari, Android APK или воспроизведение Morph в Office. Перед выпуском очередной версии приложения проверки необходимо повторить.'}
# Keep approved three-slide opening unchanged in composition; update its notes and footer for the full presentation.
for i,s in enumerate(P.slides):
 for sh in s.shapes:
  if sh.name=='!!Footer':
   for p in sh.text_frame.paragraphs:
    for run in p.runs:run.text=run.text.replace('концепция оформления','проект для обсуждения')
 s.notes_slide.notes_text_frame.text=[
  'Представиться: [ФИО], [должность], [цех]. Название продукта «Оператор ДНГ». Проект вырос из повседневных задач оператора. ФИО и портрет автора пока не получены. Изображение промысла создано для оформления и не является фотографией объекта компании.',
  'Коротко представить продукт: рабочие расчёты и материалы на телефоне. После раскрытия изображения сделать паузу. Работоспособность конкретных устройств проверяется отдельно.',
  'Цель: упростить доступ оператора к проверенным расчётам и рабочим материалам непосредственно на месте работы. Далее — четыре согласованные задачи.'
 ][i]
for j,(kind,section) in enumerate(SCENES):
 i=j+4;hidden=kind in ['author','reference'];s=P.slides.add_slide(P.slide_layouts[6]);light=kind=='tasks';s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor.from_string(Y if light else B)
 state={'hub':'hub','manual':'manual','result':'result','cooling':'cooling','ramp':'ramp','rich':'rich','vnr':'vnr','vnr_macro':'vnr_macro'}.get(kind)
 panels(s,state,rich=kind=='rich')
 if kind=='tasks':
  tx(s,72,148,1120,80,'Четыре задачи проекта',56,B,True,'!!Headline')
  for n,(h,b) in enumerate(TASKS):
   x=76+(n%2)*590;y=270+(n//2)*190
   tx(s,x,y,75,70,f'0{n+1}',38,B,True,f'TaskNumber{n}')
   tx(s,x+90,y,455,140,h,30,B,True,f'TaskTitle{n}')
 elif kind=='hub':
  # The full card composition carries the title in the header.
  pass
 elif kind=='manual':
  tx(s,102,180,420,110,'Ручной замер',42,B,True,'!!Headline')
  tx(s,106,335,415,160,'Запустил.\nИзмерил.\nПолучил результат.',36,B,True,'!!Subtitle')
  tx(s,108,540,410,70,'Автоматическое сохранение\nи история на устройстве',22,B)
 elif kind=='result':
  tx(s,76,168,550,190,'144',174,Y,True,'!!Headline');tx(s,88,378,500,80,'м³/сут',57,W,True,'!!Subtitle')
  tx(s,90,508,500,90,'100 литров / 60 секунд\nМатематический пример',27,M)
 elif kind=='interval':
  title(s,'Переход через полночь.',w=1120,z=55)
  tx(s,78,330,1140,130,'23:50 → 00:10',100,Y,True,'!!Time')
  tx(s,85,500,1100,95,'20 минут · следующая дата\n100 л → 7,2 м³/сут',31,W)
  for n,x in enumerate([90,425,805,1190]):rect(s,x,610,6,22,Y,name=f'TimeTick{n}')
  rect(s,90,620,1100,2,'666666','TimeLine')
 elif kind=='cooling':
  title(s,'Охлаждение ПЭД.', 'Расчёт по исходным данным\nв рабочей ситуации.',w=660,z=56)
  rows(s,['Параметры двигателя','Необходимые исходные данные','Проверка применимости результата'],y=495,w=650,z=24,step=48)
 elif kind=='stations':
  title(s,'Своя станция.\nСвоя инструкция.',w=625,z=54)
  brands=['Борец КАСКАД-НТ','Эталон ЧР','ЭЛЕКТОН','ОРИОН-01','ТРИОЛ (УМКА)']
  for n,t in enumerate(brands):tx(s,80,350+n*49,585,45,t,27,Y if n==0 else W,bold=n==0)
  for n in range(7):pic(s,'station.jpg',730+n*67,155+n*8,63,430,f'!!PhotoStrip{n}',[n/7,.04,1-(n+1)/7,.04])
  tx(s,730,612,480,37,'Архивное фото · не рекомендуемые уставки',14,M)
 elif kind=='ramp':
  title(s,'Разгон.\nВыдержать порядок.', 'Материалы для выбранной\nмодели станции.',w=660,z=54)
  rows(s,['Выбрать станцию','Ввести исходные условия','Сверить параметры и действия'],y=495,w=640,z=24,step=48)
  for n in range(7):pic(s,'station.jpg',730+n*67,-650-n*45,63,430,f'!!PhotoStrip{n}',[n/7,.04,1-(n+1)/7,.04])
 elif kind=='rich':
  title(s,'РИЧ.\nСвоё меню и шаги.', 'Пошаговые материалы\nи фотографии оборудования.',w=660,z=54)
  rows(s,['Пять моделей станций','Инструкции не смешиваются','Действия контролирует персонал'],y=495,w=640,z=24,step=48)
 elif kind=='vnr':
  tx(s,76,160,650,185,'207',170,Y,True,'!!Headline');tx(s,87,380,610,110,'страниц ВНР\nна телефоне',46,W,True,'!!Subtitle')
  tx(s,90,550,610,60,'Офлайн после предварительной загрузки',23,M)
 elif kind=='vnr_macro':
  title(s,'Найти.\nСохранить. Вернуться.',w=570,z=43)
  rows(s,['Поиск с подсветкой','Переходы по совпадениям и ссылкам','Закладки для быстрого возврата'],y=445,w=550,z=23,step=58)
 elif kind=='tools':
  title(s,'Больше рабочих\nинструментов.',w=680,z=54)
  tx(s,76,315,650,65,'Для опытного оператора\nи обучения новичка',24,M)
  rows(s,['Уровень, частота и приток','Потенциал, РПД, коэффициент 2А','Отпайка и помощник оператора'],y=390,w=635,z=25,step=66)
  for n,(asset,x,y,w,h) in enumerate([('tap.png',790,155,195,422),('technologist.png',1010,235,182,394)]):
   pic(s,asset,x,y,w,h,f'!!Tool{n}')
 elif kind=='sources':
  title(s,'На чём основан проект.',w=1130,z=56)
  for n,(h,b) in enumerate([('Формулы','Android-эталон.\nИсходные расчёты\nи единицы измерения.'),('Документы','Доступный регламент ВНР.\nМатериалы ПБ и ОТ —\nсверка редакций.'),('Практика','Рабочие ситуации автора.\nУчебные материалы\nи обратная связь.')]):
   x=80+n*390;rect(s,x,350,340,4,Y);tx(s,x,390,340,70,h,36,Y,True);tx(s,x,495,340,140,b,26,W)
 elif kind=='development':
  tx(s,76,185,1120,165,'3 месяца',130,Y,True,'!!Headline');tx(s,86,385,1100,85,'разработки программы',48,W,True,'!!Subtitle')
  tx(s,90,520,1100,105,'Прямые денежные расходы, по оценке автора, минимальны.\nОсновной вклад — время.',27,M)
 elif kind=='audience':
  tx(s,76,180,700,180,'≈250',156,Y,True,'!!Headline');tx(s,87,405,760,120,'потенциальных\nпользователей',45,W,True,'!!Subtitle');tx(s,90,575,1100,45,'Оценка автора · начать с ограниченного пилота',25,M)
  for n in range(50):rect(s,900+(n%5)*60,205+(n//5)*33,13,13,Y if n<10 else '444444',f'Audience{n}')
 elif kind=='effects':
  title(s,'Проверяемая польза.',w=1130,z=56)
  for n,(h,b) in enumerate([('Время','Сколько занимает\nтиповая операция.'),('Корректность','Расчёт и последовательность\nв учебном сценарии.'),('Доступность','Нужные материалы\nбез интернета.')]):
   x=80+n*390;tx(s,x,340,350,80,h,35,Y,True);tx(s,x,460,350,120,b,26,W)
  tx(s,82,610,1120,40,'Финансовый эффект — по данным пилота, без вымышленных сумм.',21,M)
 elif kind=='pilot':
  title(s,'Предложение: пилот.', 'Проверить содержание. Оценить применение.\nПринять решение по результатам.',w=1120,z=56,suby=305)
  names=[('Проверка','Профильные специалисты'),('Пилот','Ограниченная группа'),('Измерения','Единые показатели'),('Решение','Подтверждённый эффект')]
  rect(s,85,490,1080,3,Y,'!!PilotLine')
  for n,(h,b) in enumerate(names):
   x=85+n*290;rect(s,x,483,15,15,Y);tx(s,x,530,270,55,h,31,W,True);tx(s,x,595,270,45,b,18,M)
 elif kind=='closing':
  pic(s,'oilfield_illustration.png',0,0,1280,720,'!!OilfieldImage',focus=.7)
  tx(s,72,155,950,95,'ОПЕРАТОР ДНГ',70,W,True,'!!ProductTitle')
  tx(s,77,315,850,160,'Рабочие инструменты.\nВсегда рядом.',54,Y,True,'!!ProductSubtitle')
  tx(s,80,550,900,70,'Предложение: профильная проверка и пилот.',29,W)
 elif kind=='author':
  title(s,'Автор проекта', '[ФИО]\n[Должность · номер цеха]',w=760,z=56,suby=365)
  rect(s,875,160,300,450,'242424','PortraitFrame');tx(s,920,340,215,120,'Фото автора\nпока не получено',27,M)
 elif kind=='reference':
  title(s,'Расчёты и ограничения',w=1130,z=54)
  rows(s,['Q = 86,4 × V / t  ·  литры, секунды → м³/сут','100 л / 60 с → 144 м³/сут; 100 л / 1200 с → 7,2 м³/сут','Отчёт PWA v3: 58 тестов, 479 эталонных наборов, 6 проверок сборки','Реальные iPhone, Android и PowerPoint здесь не испытаны'],y=345,w=1110,z=24,step=68)
 chrome(s,i,section,light)
 if hidden:s._element.set('show','0')
 morph(s,hidden=hidden)
 s.notes_slide.notes_text_frame.text=NOTES[kind]+'\n\nСлайд управляется щелчком. Скриншоты иллюстративны; внутри PowerPoint формы не выполняют расчёт. Воспроизведение Morph в настоящем Microsoft PowerPoint здесь не проверено.'
# Navigation: card overview → feature; section header → overview; screenshot → macro → back.
bykind={k:P.slides[3+i] for i,(k,_) in enumerate(SCENES)};hub=bykind['hub']
for j,k in enumerate(['manual','cooling','ramp','vnr']):
 for sh in hub.shapes:
  if sh.name in [f'!!Panel{j}',f'!!PanelImage{j}',f'!!PanelTitle{j}']:sh.click_action.target_slide=bykind[k]
for k in ['manual','result','interval','cooling','stations','ramp','rich','vnr','vnr_macro','tools']:
 sh=tx(bykind[k],1010,88,200,28,'← Все инструменты',15,Y,name='!!BackToOverview');sh.click_action.target_slide=hub
for k,j,to in [('manual',0,'result'),('result',0,'manual'),('vnr',3,'vnr_macro'),('vnr_macro',3,'vnr')]:
 for sh in bykind[k].shapes:
  if sh.name==f'!!PanelImage{j}':sh.click_action.target_slide=bykind[to]
# Reassert product identity in the package.
P.core_properties.title='Оператор ДНГ — рабочая презентация';P.core_properties.subject='Цель, четыре согласованные задачи, функции и предложение пилота';P.core_properties.author='Автор проекта — данные уточняются'
P.save(R/'OperatorDNG_Working_Presentation.pptx')
meta=[{'slide':i+1,'kind':k,'hidden':k in ['author','reference']} for i,k in enumerate(['opening','reveal','goal']+[x[0] for x in SCENES])]
(R/'SCENES.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));(R/'PANELS.json').write_text(json.dumps(GEOM));(R/'APPROVED_TASKS.json').write_text(json.dumps(TASKS,ensure_ascii=False,indent=2))
print('Built',len(P.slides),'slides;',sum(not x['hidden'] for x in meta),'main')
