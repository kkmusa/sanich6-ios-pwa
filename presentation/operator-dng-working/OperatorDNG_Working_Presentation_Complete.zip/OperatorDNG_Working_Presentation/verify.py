from pathlib import Path
import json,zipfile,math
from pptx import Presentation
import fitz
from lxml import etree
R=Path(__file__).parent;P=Presentation(R/'OperatorDNG_Working_Presentation.pptx');D=fitz.open(R/'OperatorDNG_Working_Presentation.pdf')
N={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main','mc':'http://schemas.openxmlformats.org/markup-compatibility/2006','p159':'http://schemas.microsoft.com/office/powerpoint/2015/09/main'}
assert len(P.slides)==23 and len(D)==21
main=[s for s in P.slides if s._element.get('show')!='0'];assert len(main)==21
links=0
for i,s in enumerate(P.slides):
 assert s.has_notes_slide and len(s.notes_slide.notes_text_frame.text)>80
 names=[q.name for q in s.shapes];assert len(names)==len(set(names)),(i,names)
 if i<21:
  assert s._element.find('.//p159:morph',N) is not None
  assert s._element.find('.//mc:Fallback/p:transition/p:push',N) is not None
 for t in s._element.findall('.//p:transition',N):assert t.get('advTm') is None
 for sh in s.shapes:
  if sh._element.find('.//a:hlinkClick',N) is not None:
   assert sh.click_action.target_slide is not None;links+=1
assert links==26,links
# Approved opening retained exactly in positions and sizes.
original=Presentation(R/'Approved_Opening.pptx')
for i in range(3):
 assert len(original.slides[i].shapes)==len(P.slides[i].shapes)
 for a,b in zip(original.slides[i].shapes,P.slides[i].shapes):assert (a.name,a.left,a.top,a.width,a.height)==(b.name,b.left,b.top,b.width,b.height)
# The four approved task headings are present; exact descriptions remain in the notes.
tasks=json.loads((R/'APPROVED_TASKS.json').read_text());assert len(tasks)==4
texts=[s.text for s in P.slides[3].shapes if s.has_text_frame]
notes=P.slides[3].notes_slide.notes_text_frame.text
for h,b in tasks:assert h in texts and h+' — '+b in notes
# Meaningful motion: actual card geometry and crop change.
def find(i,n):return next(sh for sh in P.slides[i].shapes if sh.name==n)
for detail,j in [(5,0),(8,1),(10,2),(12,3)]:
 a=find(4,f'!!Panel{j}');b=find(detail,f'!!Panel{j}');assert (a.left,a.top,a.width,a.height)!=(b.left,b.top,b.width,b.height) and a.width!=b.width
for a,b,j in [(5,6,0),(12,13,3)]:assert abs(find(a,f'!!PanelImage{j}').crop_bottom-find(b,f'!!PanelImage{j}').crop_bottom)>.1
for j in range(7):assert find(9,f'!!PhotoStrip{j}').top!=find(10,f'!!PhotoStrip{j}').top
# Detect text outside pages and intersections of separate text blocks in the actual PDF.
clipped=[];collisions=[]
for i,page in enumerate(D):
 spans=[]
 for bi,b in enumerate(page.get_text('dict')['blocks']):
  for l in b.get('lines',[]):
   for sp in l['spans']:
    rect=fitz.Rect(sp['bbox']);spans.append((bi,rect,sp['text']))
    if rect.x0<-.5 or rect.y0<-.5 or rect.x1>page.rect.width+.5 or rect.y1>page.rect.height+.5:clipped.append([i+1,sp['text']])
 for a,(ba,ra,ta) in enumerate(spans):
  for bb,rb,tb in spans[a+1:]:
   if ba==bb:continue
   inter=ra&rb
   if inter.get_area()>min(ra.get_area(),rb.get_area())*.15:collisions.append([i+1,ta,tb])
assert not clipped,clipped
assert not collisions,collisions
with zipfile.ZipFile(R/'OperatorDNG_Working_Presentation.pptx') as z:
 assert z.testzip() is None
 for n in z.namelist():
  if n.endswith('.xml'):
   xml=z.read(n).decode();assert 'Саныч' not in xml and 'САНЫЧ' not in xml
assert math.isclose(86.4*100/60,144) and math.isclose(86.4*100/1200,7.2)
report={'product':'Оператор ДНГ','pptx_slides':23,'main_slides':21,'hidden_reference_slides':2,'pdf_pages':21,'approved_task_headings_and_notes':4,'approved_opening_geometry':'unchanged','internal_navigation_actions':links,'morph_with_push_fallback':21,'card_expansions':4,'macro_crop_transitions':2,'moving_photo_strips':7,'pdf_text_outside_page':clipped,'pdf_intersecting_separate_text_blocks':collisions,'mathematical_examples':'passed','old_product_name_in_xml':False,'office_playback':'NOT TESTED','actual_phone_tests':'NOT PERFORMED','preview':'Opening only; independent animatic, not Office recording'}
(R/'VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
