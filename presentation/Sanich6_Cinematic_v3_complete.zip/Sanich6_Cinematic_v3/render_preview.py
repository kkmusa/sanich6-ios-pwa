from pathlib import Path
import json,math,subprocess
import fitz
from PIL import Image,ImageDraw,ImageFont,ImageOps,ImageChops
R=Path(__file__).parent;W,H=960,540;SCALE=72
K=json.loads((R/'keyframes.json').read_text());D=json.loads((R/'scenes.json').read_text());CH=[0,1,7,8,11,12]
pdf=fitz.open(R/'preview_sources/Text_Layers.pdf')
plates={}
for i in CH:
 p=pdf[i].get_pixmap();plates[i]=Image.frombytes('RGB',[p.width,p.height],p.samples).resize((W,H))
assets={name:Image.open(R/'assets'/f'{name}.png').convert('RGB') for name in ['home','manual','vnr']}
hardware=ImageOps.fit(Image.open(R/'assets/station.jpg').convert('RGB'),(800,800));bg=(8,12,19);gold=(255,204,56);line=(49,66,86)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',9)
def graph(z):
 out=Image.new('RGB',(W,H),bg);cx,cy,rad,ang=[z[x] for x in ['cx','cy','rad','angle']];rr=int(rad*SCALE);x=int(cx*SCALE-rr);y=int(cy*SCALE-rr)
 size=max(2,rr*2);photo=hardware.resize((size,size),Image.Resampling.BILINEAR).rotate(-ang,resample=Image.Resampling.BILINEAR)
 circle=Image.new('L',(size,size));ImageDraw.Draw(circle).ellipse((0,0,size-1,size-1),fill=23);out.paste(photo,(x,y),circle)
 draw=ImageDraw.Draw(out)
 for n,f in enumerate([1,.86,.68,.49]):
  r=rad*f*SCALE;box=(cx*SCALE-r,cy*SCALE-r,cx*SCALE+r,cy*SCALE+r)
  draw.arc(box,start=ang+n*81,end=ang+n*81+110,fill=gold if n in [0,2] else line,width=2 if n==0 else 1)
 for n in range(8):
  th=math.radians(ang+n*45);xx=cx*SCALE+math.cos(th)*rad*.92*SCALE;yy=cy*SCALE+math.sin(th)*rad*.92*SCALE
  draw.ellipse((xx-2,yy-2,xx+2,yy+2),fill=gold if n==0 else line)
 return out

def phone(img,z,source,dest_source=None,blend=0,kind=''):
 x,y,w,h=[z[a]*SCALE for a in ['px','py','pw','ph']];w=max(1,int(w));h=max(1,int(h))
 if x>W+20:return
 def bitmap(src):
  data=assets[src]
  if kind=='bookmark':data=data.crop((0,0,data.width,int(data.height*.72)))
  return ImageOps.fit(data,(w,h),method=Image.Resampling.BILINEAR,centering=(.5,.5))
 pic=bitmap(source)
 if dest_source and dest_source!=source:pic=Image.blend(pic,bitmap(dest_source),blend)
 dr=ImageDraw.Draw(img);dr.rounded_rectangle((x-5,y-5,x+w+5,y+h+5),radius=8,fill=line);img.paste(pic,(int(x),int(y)))

def frame(a,b,t):
 za,zb=K[a],K[b];z={key:za[key]+(zb[key]-za[key])*t for key in za if isinstance(za[key],(int,float))}
 z['asset']=za['asset'];base=graph(z);phone(base,z,za['asset'],zb['asset'],t, D[b]['kind'] if t>.5 else D[a]['kind'])
 plate=Image.blend(plates[a],plates[b],t) if a!=b else plates[a];base=ImageChops.lighter(base,plate)
 dr=ImageDraw.Draw(base);dr.text((330,8),'АНИМАТИК · ДВИЖЕНИЯ ОБЪЕКТОВ · НЕ ЗАПИСЬ POWERPOINT',font=font,fill=(145,155,170))
 return base
out=R/'Sanich6_Motion_Preview.mp4';log=R/'PREVIEW_RENDER.txt'
with log.open('w') as err:
 proc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','21','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE,stderr=err)
 count=0
 try:
  for j,i in enumerate(CH):
   still=frame(i,i,0)
   for _ in range(36):proc.stdin.write(still.tobytes());count+=1
   if j<len(CH)-1:
    for k in range(39):
     t=(k+1)/39;t=t*t*(3-2*t);proc.stdin.write(frame(i,CH[j+1],t).tobytes());count+=1
 finally:proc.stdin.close()
 assert proc.wait()==0,log.read_text()
print(f'Preview rendered: {count} frames, {count/30:.1f}s; independent motion animatic, not Microsoft PowerPoint capture.')
