from pathlib import Path
import json,math
from PIL import Image
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from lxml import etree
R=Path(__file__).parent;D=json.loads((R/'scenes.json').read_text());P=Presentation();P.slide_width=Inches(13.333);P.slide_height=Inches(7.5)
COL={'bg':'080C13','white':'F6F7FB','gold':'FFCC38','blue':'8FD8F7','muted':'A1AFC2','line':'314256','panel':'101B2B'}
NS={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main','mc':'http://schemas.openxmlformats.org/markup-compatibility/2006','p159':'http://schemas.microsoft.com/office/powerpoint/2015/09/main','p14':'http://schemas.microsoft.com/office/powerpoint/2010/main'}
def color(key):return RGBColor.from_string(COL.get(key,key))
def alpha(shape,amount):
 sf=shape._element.find('.//a:solidFill',NS)
 if sf is not None and len(sf):etree.SubElement(sf[0],'{'+NS['a']+'}alpha',val=str(int(amount*100000)))
def shape(s,x,y,w,h,kind=MSO_SHAPE.OVAL,fill='panel',outline=None,width=1,opacity=1,name=None,rot=0):
 a=s.shapes.add_shape(kind, Inches(x),Inches(y), Inches(w),Inches(h));a.rotation=rot
 if fill is None:a.fill.background()
 else:a.fill.solid();a.fill.fore_color.rgb=color(fill);alpha(a,opacity)
 if outline:a.line.color.rgb=color(outline);a.line.width=Pt(width)
 else:a.line.fill.background()
 if name:a.name=name
 if kind==MSO_SHAPE.ROUNDED_RECTANGLE:
  try:a.adjustments[0]=.06
  except:pass
 return a
def tx(s,x,y,w,h,value,size=24,c='white',bold=False,name=None):
 a=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));a.text_frame.word_wrap=True
 for attr in ['margin_left','margin_right','margin_top','margin_bottom']:setattr(a.text_frame,attr,0)
 for i,line in enumerate(value.split('\n')):
  p=a.text_frame.paragraphs[0] if i==0 else a.text_frame.add_paragraph();p.text=line;p.font.name='Arial';p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=color(c);p.space_after=Pt(3)
 if name:a.name=name
 return a
def image(s,file,x,y,w,h,name,circle=False,rot=0,crop=None):
 a=s.shapes.add_picture(str(R/'assets'/file), Inches(x),Inches(y), width=Inches(w),height=Inches(h));a.name=name;a.rotation=rot
 iw,ih=Image.open(R/'assets'/file).size
 if crop:
  a.crop_left,a.crop_top,a.crop_right,a.crop_bottom=crop
 elif iw/ih>w/h:
  remain=(w/h)/(iw/ih);a.crop_left=(1-remain)/2;a.crop_right=(1-remain)/2
 else:
  remain=(iw/ih)/(w/h);a.crop_top=(1-remain)/2;a.crop_bottom=(1-remain)/2
 if circle:a._element.find('.//a:prstGeom',NS).set('prst','ellipse')
 return a
# Keyframes deliberately change position/size/crop/rotation, not just a transition label.
S=[]
for i,d in enumerate(D):
 k=d['kind'];cx,cy,rad=10.8,3.75,3.5
 px,py,pw,ph=9.8,.95,2.6,5.55;ang=i*27
 asset={'ramp':'ramp','rich':'rich','cooling':'ped','manual':'manual','result':'manual','interval':'manual','timer':'manual','document':'vnr','bookmark':'vnr','tap':'tap','learning':'technologist'}.get(k,'home')
 if k=='opening':cx,cy,rad=10.6,3.5,3.1;px,py,pw,ph=9.7,1.15,2.45,5.2
 if k=='reveal':cx,cy,rad=6.65,3.75,3.7;px,py,pw,ph=5.24,.72,2.85,6.0
 if k=='audience':cx,cy,rad=3.25,3.65,2.6;px=14.1
 if k=='riskmap':cx,cy,rad=10.0,3.8,3.2;px=14.1
 if k=='rich':cx,cy,rad=9.7,3.65,3.0;px,py,pw,ph=9.0,1.25,2.5,5.3
 if k=='result':cx,cy,rad=3.7,3.9,3.3;px,py,pw,ph=10.3,2.3,1.8,3.85
 if k=='interval':cx,cy,rad=9.8,3.7,2.9;px=14.1
 if k=='timer':cx,cy,rad=10.4,3.75,3.5;px,py,pw,ph=9.9,1.25,2.35,5.0
 if k=='document':cx,cy,rad=10.1,3.7,3.35;px,py,pw,ph=9.25,.9,2.65,5.65
 if k=='bookmark':cx,cy,rad=10.1,3.75,3.9;px,py,pw,ph=8.8,1.35,3.05,4.76
 if k in ['productmap','quality','sources','development','proof','effects','economics','pilot','closing']:px=14.1
 if k in ['development','proof']:cx,cy,rad=10.3,3.8,3.0
 if k=='closing':cx,cy,rad=6.666,3.75,5.1
 S.append(dict(cx=cx,cy=cy,rad=rad,px=px,py=py,pw=pw,ph=ph,angle=ang,asset=asset))

def transition(s,morph):
 if morph:
  alt=etree.Element('{'+NS['mc']+'}AlternateContent',nsmap=NS);choice=etree.SubElement(alt,'{'+NS['mc']+'}Choice',Requires='p159');t=etree.SubElement(choice,'{'+NS['p']+'}transition',spd='slow',advClick='1');t.set('{'+NS['p14']+'}dur','1300');etree.SubElement(t,'{'+NS['p159']+'}morph',option='byObject');fall=etree.SubElement(alt,'{'+NS['mc']+'}Fallback');t=etree.SubElement(fall,'{'+NS['p']+'}transition',spd='slow',advClick='1');etree.SubElement(t,'{'+NS['p']+'}fade');s._element.insert(2,alt)
 else:
  t=etree.Element('{'+NS['p']+'}transition',spd='slow',advClick='1');etree.SubElement(t,'{'+NS['p']+'}fade');s._element.insert(2,t)

def orb(s,z,i):
 cx,cy,rad,ang=[z[x] for x in ['cx','cy','rad','angle']]
 shape(s,cx-rad,cy-rad,2*rad,2*rad,fill='panel',name='!!OrbBase')
 image(s,'station.jpg',cx-rad*.93,cy-rad*.93,rad*1.86,rad*1.86,'!!HardwareLens',circle=True,rot=ang)
 shape(s,cx-rad,cy-rad,2*rad,2*rad,fill='bg',opacity=.91,name='!!LensTint')
 for n,f in enumerate([1,.86,.68,.49]):
  a=shape(s,cx-rad*f,cy-rad*f,rad*f*2,rad*f*2,kind=MSO_SHAPE.ARC,fill=None,outline='gold' if n in [0,2] else 'line',width=1.6 if n==0 else .9,name=f'!!OrbitArc{n}',rot=(ang+n*81)%360)
 # A moving point and short ring ticks make the angular motion legible.
 for n in range(8):
  theta=math.radians(ang+n*45);r=rad*.92
  shape(s,cx+math.cos(theta)*r-.035,cy+math.sin(theta)*r-.035,.07,.07,fill='gold' if n==0 else 'line',name=f'!!OrbitNode{n}')

def phone(s,z,k):
 x,y,w,h=[z[v] for v in ['px','py','pw','ph']]
 shape(s,x-.07,y-.07,w+.14,h+.14,MSO_SHAPE.ROUNDED_RECTANGLE,fill='line',name='!!PhoneFrame')
 # Native cropped screenshot; no artificial production readings.
 crop=None
 if k=='bookmark':crop=(0,0,0,.28)
 image(s,z['asset']+'.png',x,y,w,h,'!!AppScreen',crop=crop)

def eyebrow(s,i,k):
 tx(s,.6,.28,11.9,.24,'САНЫЧ-6  /  '+('МАТЕРИАЛЫ ДЛЯ ВОПРОСОВ' if k=='appendix' else 'ПРОЕКТ ВНЕДРЕНИЯ'),10,'gold',True,'!!Eyebrow')
 tx(s,.6,7.04,11.6,.24,'ООО «РН-Юганскнефтегаз» · проект для обсуждения',9,'muted',False,name='!!Footer')
 tx(s,12.0,7.04,.8,.24,f'{i+1:02d} / {len(D):02d}',9,'gold')
 shape(s,0,7.46,13.333*(i+1)/len(D),.04,MSO_SHAPE.RECTANGLE,'gold',name='!!Progress')
def maintext(s,d,x=.65,y=1.05,w=8.65,size=43,suby=3.15):
 tx(s,x,y,w,1.8,d['title'],size,'white',True,'!!Headline');tx(s,x+.02,suby,w,.85,d['sub'],21,'muted',name='!!Subline')
def rows(s,items,x=.72,y=4.28,w=7.95,size=21):
 for n,it in enumerate(items):
  shape(s,x,y+n*.62,.035,.38,MSO_SHAPE.RECTANGLE,'gold',name=f'!!StepMarker{n}')
  tx(s,x+.2,y+n*.62,w,.50,it,size,'white',name=f'!!Topic{n}')
for i,d in enumerate(D):
 s=P.slides.add_slide(P.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=color('bg');k=d['kind'];z=S[i]
 if k!='appendix':orb(s,z,i);phone(s,z,k)
 eyebrow(s,i,k)
 if k=='opening':
  tx(s,.65,1.45,8.9,1.3,d['title'],92,'white',True,'!!Headline');tx(s,.72,3.3,7.8,1.3,'Опора оператора\nв каждом действии.',38,'gold',True,'!!Subline');tx(s,.75,5.68,7.7,.8,'Рабочая версия 3.0.0\nAndroid + iPhone',20,'muted');
 elif k=='reveal':
  tx(s,.65,1.2,4.2,2.0,'Рабочий\nинструмент.',43,'white',True,'!!Headline');tx(s,.7,4.1,4.1,1.1,'Расчёты\nи инструкции рядом.',25,'muted',name='!!Subline');tx(s,8.85,2.4,3.7,1.2,'В момент,\nкогда нужно.',33,'gold',True)
 elif k=='audience':
  tx(s,1.1,2.3,6.2,1.6,'≈250',118,'gold',True,'!!Headline');tx(s,7.4,1.3,5.2,1.7,'Общий инструмент.\nРазный опыт.',36,'white',True,'!!Subline');rows(s,['Ориентировочная аудитория','Поддержка оператора и наставника','Пилот перед масштабированием'],x=7.4,y=4.0,w=4.8,size=18)
 elif k=='riskmap':
  maintext(s,d,size=42,suby=3.2);labels=['ИCХОДНЫЕ ДАННЫЕ','РАСЧЁТ','ДЕЙСТВИЕ','СВЕРКА']
  for j,it in enumerate(labels):
   x=.75+j*3.1;shape(s,x,4.72,.16,.16,fill='gold');tx(s,x,5.1,2.9,.55,it,17,'white',True)
   if j<3:shape(s,x+.15,4.79,2.94,.014,MSO_SHAPE.RECTANGLE,'line')
 elif k in ['ramp','rich','cooling','tap']:
  maintext(s,d,w=8.0,size=39,suby=3.0)
  content={'ramp':['Задание → параметры','Инструкция своей станции','Сверка темпа и последовательности'],'rich':['Станция → нужный режим','Пошаговое меню и фотографии','Контроль выполняет персонал'],'cooling':['Исходные параметры ПЭД','Рабочий и номинальный ток','Контроль применимости результата'],'tap':['Питание и параметры двигателя','Потери напряжения в кабеле','Вариант с ЧРП / без ЧРП']}[k]
  rows(s,content,size=20)
 elif k=='manual':
  tx(s,.65,1.5,8.8,1.65,'7–9',130,'gold',True,'!!Headline');tx(s,.78,3.65,7.5,.7,'замеров за активный день',30,'white',True,'!!Subline');tx(s,.8,4.75,7.5,1.1,'Рабочий сценарий автора.\nЧастота не распространяется автоматически\nна всех пользователей.',20,'muted')
 elif k=='result':
  tx(s,1.0,2.0,8.4,2.0,'144',160,'gold',True,'!!Headline');tx(s,1.3,4.2,7.6,.6,'м³/сут',43,'white',True,'!!Subline');tx(s,1.35,5.4,7.5,.7,'100 литров / 60 секунд\nМатематический пример',22,'muted')
 elif k=='interval':
  tx(s,.7,1.7,10.0,1.25,'23:50 → 00:10',67,'gold',True,'!!Headline');tx(s,.78,3.4,7.2,.7,'20 минут через полночь',35,'white',True,'!!Subline');tx(s,.8,4.65,7.1,1.1,'Даты начала и окончания выбираются отдельно.\nПример: 100 л за 20 минут → 7,2 м³/сут.',22,'muted')
  for j,a in enumerate([270,300,330,0,30,60,90]):
   theta=math.radians(a);cx,cy,rr=10.5,4.6,1.2;shape(s,cx+math.cos(theta)*rr-.025,cy+math.sin(theta)*rr-.025,.05,.05,fill='gold')
 elif k=='timer':
  maintext(s,d,w=8.0,size=44,suby=3.2);rows(s,['Состояние таймера сохраняется','Возврат к текущему замеру','История на этом устройстве'],size=21)
 elif k=='document':
  tx(s,.65,1.6,8.0,1.85,'207',138,'gold',True,'!!Headline');tx(s,.78,3.8,7.5,1.0,'страниц ВНР\nна телефоне',33,'white',True,'!!Subline');tx(s,.8,5.5,7.6,.55,'Офлайн после предварительной загрузки',20,'muted')
 elif k=='bookmark':
  maintext(s,d,w=7.7,size=41,suby=3.35);rows(s,['Найти совпадение','Открыть ссылку','Вернуться к закладке'],w=7.0,size=22)
 elif k=='learning':
  maintext(s,d,size=48,suby=3.4);rows(s,['Помощник по рабочим ситуациям','Инструкции пяти станций','Практический показ с наставником'],w=8.2)
 elif k=='productmap':
  tx(s,.7,1,11.8,1.1,d['title'],56,'white',True,'!!Headline');tx(s,.75,2.3,11.5,.5,d['sub'],15,'gold',True,'!!Subline')
  for j,(a,b) in enumerate([('01','Расчёты'),('02','Технолог'),('03','Справочник'),('04','История')]):
   x=.8+j*3.1;tx(s,x,3.7,2.8,.6,a,36,'gold',True);tx(s,x,4.65,2.9,.7,b,25,'white',True);shape(s,x,5.6,2.7,.025,MSO_SHAPE.RECTANGLE,'line')
 elif k=='quality':
  maintext(s,d,size=42,suby=3.25);rows(s,['Корректные исходные параметры','Сопоставление расчёта с фактом','Применимость проверяет специалист'],w=11.8,size=22)
 elif k=='sources':
  maintext(s,d,size=45,suby=3.3);rows(s,['ВНР: документ и реквизиты подтверждены','ПБиОТ, пять томов: сверить редакции и разделы','Android: исходные формулы и материалы'],w=11.8,size=22)
 elif k=='development':
  tx(s,.65,1.5,10.6,1.8,'3 месяца',105,'gold',True,'!!Headline');tx(s,.8,3.6,10.5,.9,'разработки программы',41,'white',True,'!!Subline');tx(s,.82,5.0,10.5,.95,'Прямые денежные расходы, по оценке автора, минимальны.\nЗатраченное время — отдельный ресурс.',23,'muted')
 elif k=='proof':
  maintext(s,d,size=48,suby=2.9)
  for j,(a,b) in enumerate([('58','локально пройденных тестов'),('479','эталонных наборов Kotlin'),('6','проверок готовой сборки')]):
   x=.8+j*4.1;tx(s,x,4.0,3.8,1.3,a,84,'gold',True,name=f'!!ProofNumber{j}');tx(s,x+.04,5.6,3.65,.8,b,19,'white')
 elif k=='effects':
  maintext(s,d,size=47,suby=3.0)
  for j,(a,b) in enumerate([('Время','Сопоставимые операции'),('Действия','Отклонения в сценариях'),('Обучение','Самостоятельность и помощь')]):
   x=.8+j*4.1;shape(s,x,4.3,.12,.12,fill='gold');tx(s,x,4.8,3.9,.65,a,30,'white',True);tx(s,x,5.65,3.7,.55,b,19,'muted')
 elif k=='economics':
  maintext(s,d,size=45,suby=3.0);tx(s,.85,4.1,11.7,.8,'ЗАТРАТЫ  ÷  ЭФФЕКТ СОБЫТИЯ',38,'white',True);tx(s,.85,5.25,11.8,.7,'= ПОРОГ ОКУПАЕМОСТИ',35,'gold',True);tx(s,.9,6.17,11.6,.3,'Пороговый расчёт. Частота предотвращённых событий пока не доказана.',13,'muted')
 elif k=='pilot':
  maintext(s,d,size=53,suby=2.7)
  for j,(a,b) in enumerate([('01','Подготовить'),('02','Проверить'),('03','Измерить'),('04','Решить')]):
   x=.8+j*3.1;shape(s,x+.04,4.15,.16,.16,fill='gold');tx(s,x,4.6,2.9,.7,a,40,'gold',True);tx(s,x,5.5,2.9,.6,b,24,'white',True)
   if j<3:shape(s,x+.2,4.22,2.95,.015,MSO_SHAPE.RECTANGLE,'line')
 elif k=='closing':
  tx(s,1.0,1.8,11.7,2.3,d['title'],58,'white',True,'!!Headline');tx(s,1.1,4.8,11.1,.6,'РЕАЛЬНЫЕ СЦЕНАРИИ. ПОДТВЕРЖДЁННЫЕ РЕЗУЛЬТАТЫ.',21,'gold',True,'!!Subline');tx(s,1.15,5.85,10.7,.5,'Согласовать участников, владельца и критерии пилота.',21,'muted')
 else:
  tx(s,.7,.95,11.95,1.4,d['title'],39,'white',True);tx(s,.74,2.55,11.9,.75,d['sub'],20,'muted')
  for n,it in enumerate(d.get('items',[])):
   y=3.5+n*.68;tx(s,.8,y,.5,.4,f'{n+1:02d}',15,'gold',True);tx(s,1.45,y,10.85,.65,it,18 if len(it)>120 else 20,'white')
 if d.get('source'):tx(s,.72,6.63,11.85,.27,d['source'],9,'muted')
 note=d['note']+'\n\nРежиссура: '+k+'. В основном показе сценические изменения выполняются Morph; в несовместимых версиях резервный Fade. Резервные слайды не входят в обязательный рассказ.'
 s.notes_slide.notes_text_frame.text=note;transition(s,k!='appendix')
P.save(R/'Sanich6_Cinematic_v3.pptx');(R/'keyframes.json').write_text(json.dumps(S,ensure_ascii=False,indent=2));print('Created 29-scene native PowerPoint: moving circular masks, 4 arcs, 8 orbital nodes, crop/scale changes and matched objects.')
