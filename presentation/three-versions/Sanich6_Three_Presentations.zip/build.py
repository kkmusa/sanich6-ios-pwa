from pathlib import Path
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from lxml import etree
import json
R=Path('/workspace/presentation-three'); A=Path('/workspace/sanich6-presentation-v3/assets')
N={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','mc':'http://schemas.openxmlformats.org/markup-compatibility/2006','p159':'http://schemas.microsoft.com/office/powerpoint/2015/09/main'}
def box(s,x,y,w,h,c,name,kind=MSO_SHAPE.RECTANGLE):
 q=s.shapes.add_shape(kind,Inches(x),Inches(y),Inches(w),Inches(h));q.fill.solid();q.fill.fore_color.rgb=RGBColor.from_string(c);q.line.fill.background();q.name=name;return q
def txt(s,x,y,w,h,t,z=24,c='F4F6FA',name='text',bold=False):
 q=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));q.name=name;q.text_frame.word_wrap=True
 q.text_frame.margin_left=q.text_frame.margin_right=0;q.text_frame.margin_top=q.text_frame.margin_bottom=0
 for i,line in enumerate(t.split('\n')):
  p=q.text_frame.paragraphs[0] if i==0 else q.text_frame.add_paragraph();p.text=line;p.font.name='Arial';p.font.size=Pt(z);p.font.bold=bold;p.font.color.rgb=RGBColor.from_string(c);p.space_after=Pt(10)
 return q
def pic(s,a,x,y,w,h,name):
 from PIL import Image
 q=s.shapes.add_picture(str(A/a),Inches(x),Inches(y),width=Inches(w),height=Inches(h));q.name=name
 iw,ih=Image.open(A/a).size;r=w/h
 if iw/ih>r:q.crop_left=q.crop_right=(1-r/(iw/ih))/2
 else:q.crop_top=q.crop_bottom=(1-(iw/ih)/r)/2
 return q
def trans(s):
 ac=etree.Element('{'+N['mc']+'}AlternateContent',nsmap=N);ch=etree.SubElement(ac,'{'+N['mc']+'}Choice',Requires='p159');tr=etree.SubElement(ch,'{'+N['p']+'}transition',spd='slow',advClick='1');etree.SubElement(tr,'{'+N['p159']+'}morph',option='byObject');fb=etree.SubElement(ac,'{'+N['mc']+'}Fallback');tr=etree.SubElement(fb,'{'+N['p']+'}transition',advClick='1');etree.SubElement(tr,'{'+N['p']+'}fade');s._element.insert(2,ac)
def phone(s,asset,x=9.5,y=1,w=2.65):
 box(s,x-.07,y-.07,w+.14,w*2.13+.14,'334257','!!PhoneFrame',MSO_SHAPE.ROUNDED_RECTANGLE);pic(s,asset+'.png',x,y,w,w*2.13,'!!AppScreen')
base=[
('САНЫЧ-6','Цифровой помощник оператора\nдобычи нефти и газа','home'),
('Автор проекта','[ФИО]\n[Должность · цех]','author'),
('Рабочая задача','Расчёт. Замер. Нужная инструкция.\nИнформация нужна на месте работы.','home'),
('Цель проекта','Упростить доступ оператора\nк проверенным расчётам\nи рабочим материалам.','home'),
('Задачи','Объединить расчёты и справочники.\nУпростить замеры и историю.\nПодготовить материалы для офлайна.','technologist'),
('Инструменты одной смены','Ручной замер · охлаждение ПЭД\nРазгон и РИЧ · регламент ВНР','menu'),
('Ручной замер','Запуск секундомера → объём → результат.\nИстория измерений на устройстве.','manual'),
('144 м³/сут','100 литров за 60 секунд.\nПроверяемый математический пример.','manual'),
('Охлаждение ПЭД','Исходные параметры → расчёт.\nПрименимость оценивает специалист.','ped'),
('Разгон','Выбор станции.\nИнструкция и фотографии своей модели.','ramp'),
('РИЧ','Своя последовательность действий.\nКонтроль выполняет персонал.','rich'),
('Регламент рядом','207 страниц · поиск · ссылки · закладки.\nОфлайн после предварительной загрузки.','vnr'),
('Другие рабочие расчёты','Расчёт отпайки и другие инструменты.\nФормулы перенесены из Android-эталона.','tap'),
('Материальная база','Android-эталон: формулы и материалы.\nВНР: доступный документ.\nМатериалы ПБ и ОТ: сверка редакций.','technologist'),
('3 месяца','Срок разработки — по данным автора.\nПрямые денежные расходы минимальны.\nЗатраченное время — отдельный ресурс.','home'),
('Около 250 человек','Потенциальная аудитория по оценке автора.\nПредлагается пилот перед масштабированием.','home'),
('Как оценить пользу','Время типовой задачи.\nКорректность в учебных сценариях.\nДоступность материалов без сети.','home'),
('Предложение руководству','Проверка содержания специалистами.\nОграниченный пилот.\nРешение по результатам измерений.','home'),
('Знания рядом с решением','САНЫЧ-6\nСпасибо. Готов обсудить проект.','home')]
notes='Проект для обсуждения, не утверждённое корпоративное внедрение. Приложение не управляет оборудованием и не заменяет действующие инструкции. Данные об аудитории, сроке и расходах — сведения автора. Реальный iPhone и PowerPoint на компьютере выступления здесь не испытаны.'
manifest=[]
for mode,label in [(1,'01_Experimental_One_Shift'),(2,'02_Executive'),(3,'03_Product_Showcase')]:
 P=Presentation();P.slide_width=Inches(13.333);P.slide_height=Inches(7.5)
 data=list(base)
 if mode==1:
  data[0]=('Одна смена.\nМного решений.','САНЫЧ-6 · история рабочего инструмента','field')
  data.insert(9,('От поверхности\nк рабочему расчёту','Условная схема скважины.\nНе инженерная симуляция.','well'))
 for i,(title,body,asset) in enumerate(data):
  s=P.slides.add_slide(P.slide_layouts[6]);bg='090E18' if mode!=2 else 'F0F3F7';fg='F4F6FA' if mode!=2 else '102235';muted='B2BFD0' if mode!=2 else '485C70';accent='FFCA45' if mode!=2 else '006E83'
  s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor.from_string(bg)
  txt(s,.6,.25,11,.3,['ОДНА СМЕНА / САНЫЧ-6','САНЫЧ-6 / ПРОЕКТ ВНЕДРЕНИЯ','САНЫЧ-6 / ВОЗМОЖНОСТИ'][mode-1],11,accent,'!!Eyebrow',True)
  txt(s,.6,7.12,11.5,.25,'ООО «РН-Юганскнефтегаз» · проект для обсуждения',10,muted,'!!Footer');txt(s,12,7.12,.8,.25,f'{i+1:02}',10,accent)
  if mode==1:
   # Macro/micro is represented by matched well and horizon geometry.
   horizon=4.8 if asset=='field' else 6.65
   box(s,0,horizon,13.333,.025,'344658','!!Horizon')
   wx=6.6 if asset=='well' else 11.3;wy=.9 if asset=='well' else 3.9
   box(s,wx,wy,.08,5.7-wy,'FFCA45','!!WellPath');box(s,wx-.28,5.55,.64,.7,'596E85','!!Motor',MSO_SHAPE.ROUNDED_RECTANGLE)
   for j in range(4):box(s,8+j,4.6-j*.15,.05,.65+j*.15,'344658',f'!!FieldMast{j}')
   if asset=='field':
    txt(s,.75,1.4,10.7,2.4,title,62,fg,'!!Headline',True);txt(s,.8,4.2,8,1,body,24,accent,'!!Body')
   elif asset=='well':
    txt(s,.75,1.3,5.4,2,title,40,fg,'!!Headline',True);txt(s,.8,4,5,1.3,body,24,muted,'!!Body');phone(s,'ped',9.1,1.1,2.4)
   else:
    txt(s,.75,1.2,8,1.7,title,44,fg,'!!Headline',True);txt(s,.8,3.4,7.9,2.5,body,25,muted,'!!Body')
    if asset not in ['author','menu']:phone(s,asset,9.5 if i%2 else 9.1,1.15,2.45)
  elif mode==2:
   box(s,.65,1.05,.07,5.5,accent,'!!AccentBar');txt(s,1,1.1,8,1.7,title,43,fg,'!!Headline',True);txt(s,1.05,3.25,7.7,2.8,body,25,muted,'!!Body')
   if asset not in ['author','menu']:phone(s,asset,9.6,1.15,2.4)
  else:
   txt(s,.75,1.05,7.5,1.65,title,45,fg,'!!Headline',True);txt(s,.8,3.05,7.35,2.5,body,24,muted,'!!Body')
   if asset not in ['author','menu']:phone(s,asset,9.4,1,2.55)
   for j,(a,t) in enumerate([('manual','Замер'),('ped','ПЭД'),('ramp','Разгон'),('vnr','ВНР')]):
    active=asset==a;x=.8+j*1.85
    box(s,x,6.0,1.65,.65,accent if active else '1D2A3D',f'!!NavCard{j}',MSO_SHAPE.ROUNDED_RECTANGLE);txt(s,x+.12,6.17,1.4,.3,t,15,'101828' if active else 'D9E2F0',f'!!NavLabel{j}',True)
  if asset=='author':
   box(s,9.1,1.25,2.8,4.9,'243347' if mode!=2 else 'D6E0E9','!!PortraitSlot',MSO_SHAPE.ROUNDED_RECTANGLE);txt(s,9.4,3,2.2,1.5,'МЕСТО\nДЛЯ ВАШЕГО\nПОРТРЕТА',18,muted,'portrait-label',True)
  if asset=='menu':
   # Same four panels change width/position on subsequent feature scenes in showcase.
   for j,(a,t) in enumerate([('manual','Ручной замер'),('ped','Охлаждение ПЭД'),('ramp','Разгон / РИЧ'),('vnr','Регламент ВНР')]):
    x=.8+j*3.15;box(s,x,4.7,2.95,1.55,'203347' if mode!=2 else 'DCE6EC',f'!!OverviewPanel{j}',MSO_SHAPE.ROUNDED_RECTANGLE);txt(s,x+.18,5.12,2.6,.9,t,22,fg,f'!!OverviewLabel{j}',True)
  trans(s);s.notes_slide.notes_text_frame.text=f'{title}\n{body}\n\n{notes}\n'+('Автор: заменить заполнители точными данными и портретом.' if asset=='author' else '')
 P.save(R/(label+'.pptx'));manifest.append({'file':label+'.pptx','slides':len(P.slides),'style':mode})
(R/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(manifest)
