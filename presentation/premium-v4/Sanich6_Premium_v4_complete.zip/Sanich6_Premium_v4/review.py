from pathlib import Path
import fitz,json
from PIL import Image,ImageDraw
R=Path(__file__).parent
pdf=fitz.open(R/'Sanich6_Premium_v4.pdf');print('PDF pages',len(pdf))
for base in range(0,len(pdf),6):
 canvas=Image.new('RGB',(1440,810),'#1D2735');d=ImageDraw.Draw(canvas)
 for j,i in enumerate(range(base,min(base+6,len(pdf)))):
  page=pdf[i];p=page.get_pixmap(matrix=fitz.Matrix(720/page.rect.width,720/page.rect.width));im=Image.frombytes('RGB',[p.width,p.height],p.samples);im.thumbnail((710,390));x=(j%2)*720;y=(j//2)*270
  im.thumbnail((475,267));canvas.paste(im,(x,y));d.text((x+490,y+15),f'SLIDE {i+1}',fill='white')
 canvas.save(R/f'Overview_{base//6+1}.jpg')
for i in [0,4,6,10,13,18]:
 if i<len(pdf):pdf[i].get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(R/f'Slide_{i+1:02d}.png')
# Detect clipped PDF text by page boundary, rather than treating intentionally off-canvas images as defects.
issues=[]
for i,page in enumerate(pdf):
 for b in page.get_text('dict')['blocks']:
  if 'lines' not in b:continue
  for line in b['lines']:
   for sp in line['spans']:
    x0,y0,x1,y1=sp['bbox']
    if x0<-.5 or y0<-.5 or x1>page.rect.width+.5 or y1>page.rect.height+.5:issues.append([i+1,sp['text'],sp['bbox']])
print('Text clipping:',issues)
(R/'PDF_REVIEW.json').write_text(json.dumps({'pages':len(pdf),'clipped_text':issues},ensure_ascii=False,indent=2))
