from pathlib import Path
import json,math,subprocess
import fitz
from PIL import Image,ImageDraw,ImageFont,ImageOps,ImageChops
R=Path(__file__).parent;A=R/'assets';W,H=1280,720;S=W/13.333333
K=json.loads((R/'SCENES.json').read_text());CH=[4,5,6,8,12,13];BG=(9,13,20);GOLD=(246,198,73);LINE=(42,60,81)
pdf=fitz.open(R/'Text_Layers.pdf');plates={}
for i in CH:
 p=pdf[i].get_pixmap(matrix=fitz.Matrix(W/pdf[i].rect.width,W/pdf[i].rect.width));plates[i]=Image.frombytes('RGB',[p.width,p.height],p.samples).resize((W,H))
assets=[Image.open(A/(a+'.png')).convert('RGB') for a in ['manual','ped','ramp','vnr']]
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
def lerp(a,b,t):return a+(b-a)*t
def panel(im,j,z,label_alpha=1):
 x,y,w,h,ix,iy,iw,ih,cl,ct,cr,cb=z
 if x>14 or x+w<0:return
 dr=ImageDraw.Draw(im);dr.rounded_rectangle((x*S,y*S,(x+w)*S,(y+h)*S),radius=10,fill=(19,30,44))
 src=assets[j];cw,ch=src.size;crop=src.crop((cl*cw,ct*ch,(1-cr)*cw,(1-cb)*ch));tw,th=max(1,round(iw*S)),max(1,round(ih*S))
 im.paste(crop.resize((tw,th),Image.Resampling.BILINEAR),(round(ix*S),round(iy*S)))
 if label_alpha>0:
  layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer);labels=['Замер','ПЭД','Станции','ВНР'];d.text(((x+.2)*S,(y+.18)*S),labels[j],font=font,fill=(*GOLD,int(255*label_alpha)));im.paste(layer,(0,0),layer)
def frame(a,b,t):
 ka,kb=K[a],K[b];im=Image.new('RGB',(W,H),BG);dr=ImageDraw.Draw(im)
 cx,cy,r,ang=[lerp(va,vb,t) for va,vb in zip(ka['ring'],kb['ring'])]
 for j,f in enumerate([1,.9,.71]):
  rr=r*f*S;dr.arc((cx*S-rr,cy*S-rr,cx*S+rr,cy*S+rr),start=ang+j*95,end=ang+j*95+100,fill=GOLD if j==1 else LINE,width=2 if j==1 else 1)
 for j in range(4):panel(im,j,[lerp(va,vb,t) for va,vb in zip(ka['panels'][j],kb['panels'][j])])
 blank=Image.new('RGB',(W,H),BG)
 if a==b:plate=plates[a]
 elif t<.45:plate=Image.blend(plates[a],blank,min(1,t/.45))
 else:plate=Image.blend(blank,plates[b],max(0,min(1,(t-.55)/.45)))
 im=ImageChops.lighter(im,plate)
 dr=ImageDraw.Draw(im);dr.rectangle((455,4,1220,24),fill=BG);dr.text((460,7),'АНИМАТИК ДВИЖЕНИЙ · НЕ ЗАПИСЬ MICROSOFT POWERPOINT',font=small,fill=(160,172,189))
 return im
out=R/'Sanich6_v4_Motion_Study.mp4'
with (R/'MOTION_RENDER.txt').open('w') as err:
 proc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE,stderr=err)
 count=0
 try:
  for j,i in enumerate(CH):
   pic=frame(i,i,0)
   for n in range(42):proc.stdin.write(pic.tobytes());count+=1
   if j<len(CH)-1:
    for n in range(42):
     t=(n+1)/42;t=t*t*(3-2*t);proc.stdin.write(frame(i,CH[j+1],t).tobytes());count+=1
 finally:proc.stdin.close()
 assert proc.wait()==0
print(count,'frames;',count/30,'seconds; independent animatic, not Office recording')
