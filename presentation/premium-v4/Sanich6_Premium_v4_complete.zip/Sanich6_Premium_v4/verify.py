from pathlib import Path
from pptx import Presentation
from lxml import etree
import fitz,json,zipfile
R=Path(__file__).parent;f=R/'Sanich6_Premium_v4.pptx';p=Presentation(f)
assert len(p.slides)==24
N={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main','mc':'http://schemas.openxmlformats.org/markup-compatibility/2006','p159':'http://schemas.microsoft.com/office/powerpoint/2015/09/main'}
main=[s for s in p.slides if s._element.get('show')!='0'];assert len(main)==21
for i,s in enumerate(p.slides):
 assert s.has_notes_slide and len(s.notes_slide.notes_text_frame.text)>80
 names=[sh.name for sh in s.shapes];assert len(names)==len(set(names)),(i,'duplicate names')
 if i<21:
  assert s._element.find('.//p159:morph',N) is not None
  assert s._element.find('.//mc:Fallback/p:transition/p:fade',N) is not None
 assert s._element.find('.//p:transition',N).get('advTm') is None
# Compare actual object coordinates and image crop, not only transition metadata.
def sh(i,name):return next(s for s in p.slides[i].shapes if s.name==name)
for overview,detail,j in [(4,5,0),(4,8,1),(4,10,2),(4,12,3)]:
 a=sh(overview,f'!!Panel{j}');b=sh(detail,f'!!Panel{j}')
 assert abs(a.width-b.width)>500000 and a.left!=b.left
for a,b,j in [(5,6,0),(12,13,3)]:
 a=sh(a,f'!!PanelImage{j}');b=sh(b,f'!!PanelImage{j}')
 assert abs(a.crop_bottom-b.crop_bottom)>.1 and a.width!=b.width
six=sh(0,'!!BigSix');assert six._element.find('.//a:custGeom/a:pathLst/a:path/a:cubicBezTo',N) is not None
for j in range(7):assert sh(10,f'!!Shutter{j}').height>sh(11,f'!!Shutter{j}').height*10
links=0
for s in p.slides:
 for shape in s.shapes:
  if shape._element.find('.//a:hlinkClick',N) is not None:
   assert shape.click_action.target_slide is not None;links+=1
assert links==30,links
pdf=fitz.open(R/'Sanich6_Premium_v4.pdf');assert len(pdf)==21
clipped=[]
for i,page in enumerate(pdf):
 for b in page.get_text('dict')['blocks']:
  for line in b.get('lines',[]):
   for span in line['spans']:
    x0,y0,x1,y1=span['bbox']
    if min(x0,y0)<-.5 or x1>page.rect.width+.5 or y1>page.rect.height+.5:clipped.append([i+1,span['text']])
assert not clipped,clipped
assert 86.4*100/60==144 and 86.4*100/1200==7.2
with zipfile.ZipFile(f) as z:assert z.testzip() is None
report={'pptx_slides':24,'main_slides':21,'hidden_reference_slides':3,'morph_and_fade_fallback':21,'internal_navigation_actions':links,'panel_expansions_verified':4,'screenshot_macro_transitions_verified':2,'native_photo_glyph_mask':True,'photo_shutter_strips':7,'pdf_pages':21,'pdf_text_outside_page':clipped,'math_examples':'passed','office_playback':'NOT TESTED','device_tests':'NOT PERFORMED','animatic':'independent renderer, not a recording of Office'}
(R/'VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
