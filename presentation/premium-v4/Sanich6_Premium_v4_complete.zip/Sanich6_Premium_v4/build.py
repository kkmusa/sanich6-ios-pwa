from pathlib import Path
import json,math
from PIL import Image
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from lxml import etree
R=Path(__file__).parent;A=R/'assets'
P=Presentation();P.slide_width=Inches(13.333333);P.slide_height=Inches(7.5)
BG='090D14';FG='F2F4F8';GOLD='F6C649';MUTED='A7B2C1';PANEL='131E2C';LINE='2A3C51';BLUE='9AD5ED'
NS={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships','mc':'http://schemas.openxmlformats.org/markup-compatibility/2006','p159':'http://schemas.microsoft.com/office/powerpoint/2015/09/main','p14':'http://schemas.microsoft.com/office/powerpoint/2010/main'}
TEXT=[];META=[]
def cc(c):return RGBColor.from_string(c)
def opacity(sh,n):
 a=sh._element.find('.//a:solidFill',NS)
 if a is not None and len(a):etree.SubElement(a[0],'{'+NS['a']+'}alpha',val=str(round(n*100000)))
def geom(s,x,y,w,h,c=PANEL,name=None,kind=MSO_SHAPE.RECTANGLE,line=None,weight=1,alpha=1,rot=0):
 q=s.shapes.add_shape(kind,Inches(x),Inches(y),Inches(w),Inches(h));q.rotation=rot
 if c:q.fill.solid();q.fill.fore_color.rgb=cc(c);opacity(q,alpha)
 else:q.fill.background()
 if line:q.line.color.rgb=cc(line);q.line.width=Pt(weight)
 else:q.line.fill.background()
 if name:q.name=name
 if kind==MSO_SHAPE.ROUNDED_RECTANGLE:q.adjustments[0]=.06
 return q
def text(s,x,y,w,h,t,size=24,c=FG,bold=False,name=None,spacing=0):
 q=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));q.name=name or f'Text_{len(s.shapes)}';tf=q.text_frame;tf.word_wrap=True
 tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
 for i,l in enumerate(t.split('\n')):
  p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=l;p.font.name='Arial';p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=cc(c);p.space_after=Pt(8);p.line_spacing=1.05
  if spacing:
   for run in p.runs:run._r.get_or_add_rPr().set('spc',str(spacing))
 TEXT.append({'slide':len(P.slides),'name':q.name,'text':t,'x':x,'y':y,'w':w,'h':h})
 return q
def picture(s,asset,x,y,w,h,name,crop=None,circle=False):
 q=s.shapes.add_picture(str(A/asset),Inches(x),Inches(y),width=Inches(w),height=Inches(h));q.name=name
 iw,ih=Image.open(A/asset).size
 if crop:q.crop_left,q.crop_top,q.crop_right,q.crop_bottom=crop
 elif iw/ih>w/h:q.crop_left=q.crop_right=(1-(w/h)/(iw/ih))/2
 else:q.crop_top=q.crop_bottom=(1-(iw/ih)/(w/h))/2
 if circle:q._element.find('.//a:prstGeom',NS).set('prst','ellipse')
 return q

def glyph_photo(s,letter,x,y,w,h,name):
 from fontTools.ttLib import TTFont
 from fontTools.pens.basePen import BasePen
 from fontTools.pens.boundsPen import BoundsPen
 f=TTFont('/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf');gs=f.getGlyphSet();glyph=gs[f.getBestCmap()[ord(letter)]];bp=BoundsPen(gs);glyph.draw(bp);xmin,ymin,xmax,ymax=bp.bounds
 q=picture(s,'station.jpg',x,y,w,h,name)
 sp=q._element.find('p:spPr',NS);old=sp.find('a:prstGeom',NS);sp.remove(old)
 cg=etree.SubElement(sp,'{'+NS['a']+'}custGeom')
 for tag in ['avLst','gdLst','ahLst','cxnLst']:etree.SubElement(cg,'{'+NS['a']+'}'+tag)
 etree.SubElement(cg,'{'+NS['a']+'}rect',l='0',t='0',r='w',b='h')
 pl=etree.SubElement(cg,'{'+NS['a']+'}pathLst');path=etree.SubElement(pl,'{'+NS['a']+'}path',w='100000',h='100000',fill='norm',stroke='false',extrusionOk='false')
 class Pen(BasePen):
  def point(self,parent,pt):etree.SubElement(parent,'{'+NS['a']+'}pt',x=str(round((pt[0]-xmin)/(xmax-xmin)*100000)),y=str(round((ymax-pt[1])/(ymax-ymin)*100000)))
  def _moveTo(self,pt):self.point(etree.SubElement(path,'{'+NS['a']+'}moveTo'),pt)
  def _lineTo(self,pt):self.point(etree.SubElement(path,'{'+NS['a']+'}lnTo'),pt)
  def _curveToOne(self,a,b,c):
   e=etree.SubElement(path,'{'+NS['a']+'}cubicBezTo')
   for pt in [a,b,c]:self.point(e,pt)
  def _closePath(self):etree.SubElement(path,'{'+NS['a']+'}close')
 glyph.draw(Pen(gs))
 # Picture clipped by native editable geometry, no raster text mask.
 bl=q._element.find('.//a:blip',NS);etree.SubElement(bl,'{'+NS['a']+'}alphaModFix',amt='40000')
 return q

def glow(s,cx,cy,r,name='!!Glow'):
 q=geom(s,cx-r,cy-r,2*r,2*r,GOLD,name,MSO_SHAPE.OVAL)
 sp=q._element.find('p:spPr',NS);sf=sp.find('a:solidFill',NS);sp.remove(sf)
 g=etree.SubElement(sp,'{'+NS['a']+'}gradFill',rotWithShape='1');gs=etree.SubElement(g,'{'+NS['a']+'}gsLst')
 for pos,color,alpha in [(0,'795C21',26000),(48000,'26303B',12000),(100000,BG,0)]:
  stop=etree.SubElement(gs,'{'+NS['a']+'}gs',pos=str(pos));rgb=etree.SubElement(stop,'{'+NS['a']+'}srgbClr',val=color);etree.SubElement(rgb,'{'+NS['a']+'}alpha',val=str(alpha))
 path=etree.SubElement(g,'{'+NS['a']+'}path',path='circle');etree.SubElement(path,'{'+NS['a']+'}fillToRect',l='50000',t='50000',r='50000',b='50000')
 return q

def ring(s,cx,cy,r,angle=0):
 glow(s,cx,cy,r*1.15)
 for j,(f,col) in enumerate([(1,LINE),(.9,GOLD),(.71,LINE)]):
  geom(s,cx-r*f,cy-r*f,r*f*2,r*f*2,None,f'!!Orbit{j}',MSO_SHAPE.ARC,col,.9 if j!=1 else 1.3,rot=angle+j*95)
 for j in range(6):
  a=math.radians(angle+j*60);geom(s,cx+math.cos(a)*r-.027,cy+math.sin(a)*r-.027,.054,.054,GOLD if j==0 else LINE,f'!!OrbitDot{j}',MSO_SHAPE.OVAL)

def morph(s,duration=1150,reserve=False):
 if reserve:
  tr=etree.Element('{'+NS['p']+'}transition',advClick='1');etree.SubElement(tr,'{'+NS['p']+'}fade');s._element.insert(2,tr);return
 ac=etree.Element('{'+NS['mc']+'}AlternateContent',nsmap=NS);choice=etree.SubElement(ac,'{'+NS['mc']+'}Choice',Requires='p159');tr=etree.SubElement(choice,'{'+NS['p']+'}transition',spd='slow',advClick='1');tr.set('{'+NS['p14']+'}dur',str(duration));etree.SubElement(tr,'{'+NS['p159']+'}morph',option='byObject');fb=etree.SubElement(ac,'{'+NS['mc']+'}Fallback');tr=etree.SubElement(fb,'{'+NS['p']+'}transition',advClick='1');etree.SubElement(tr,'{'+NS['p']+'}fade');s._element.insert(2,ac)

def phone(s,asset,x,y,w,h=None,name='!!Hero',crop=None):
 h=h or w*844/390
 geom(s,x-.065,y-.065,w+.13,h+.13,'263547',name+'Frame',MSO_SHAPE.ROUNDED_RECTANGLE)
 picture(s,asset+'.png',x,y,w,h,name+'Screen',crop=crop)

def chrome(s,i,section,reserve=False):
 text(s,.65,.28,5.8,.25,'САНЫЧ-6  /  '+section,9,GOLD,True,'!!Section',80)
 text(s,.65,7.12,10.9,.2,'ООО «РН-Юганскнефтегаз» · проект для обсуждения',8,MUTED,name='!!Footer')
 text(s,12.05,7.12,.7,.2,f'{i+1:02d}',9,GOLD,name='PageNumber')
 geom(s,.65,6.91,12.03,.008,LINE,'!!Baseline')
 geom(s,.65,6.91,12.03*min((i+1)/22,1),.016,GOLD,'!!Progress')

def title(s,head,sub='',w=8.5,size=46,x=.75,y=1.05,suby=3.3):
 text(s,x,y,w,1.85,head,size,FG,True,'!!Headline')
 if sub:text(s,x+.03,suby,w,1.6,sub,23,MUTED,name='!!Subline')

def points(s,rows,x=.8,y=4.3,w=7.5,size=20,step=.65):
 for j,t in enumerate(rows):
  geom(s,x,y+j*step,.035,.29,GOLD,f'Point{j}');text(s,x+.2,y-.015+j*step,w,.55,t,size,FG,name=f'PointText{j}')

PANELS=[('manual','Замер','Время → результат'),('ped','ПЭД','Приток и охлаждение'),('ramp','Станции','Разгон и РИЧ'),('vnr','ВНР','Поиск и закладки')]
# Every panel keeps its identity through the overview, expansion and macro states.
def panels(s,state):
 specs=[]
 for j,(asset,lab,desc) in enumerate(PANELS):
  if state=='overview':x,y,w,h=.75+j*3.0,2.15,2.8,4.32;ix,iy,iw,ih=x+.58,y+1.28,1.64,3.02;crop=(0,0,0,.15)
  elif isinstance(state,int) and j==state:x,y,w,h=8.45,1.02,4.0,5.65;ix,iy,iw,ih=9.18,1.5,2.5,5.15;crop=(0,0,0,.048)
  elif state=='manual_macro' and j==0:x,y,w,h=7.05,1.35,5.35,4.9;ix,iy,iw,ih=7.35,1.75,4.75,4.2;crop=(0,.23,0,.36)
  elif state=='vnr_macro' and j==3:x,y,w,h=6.8,1.35,5.6,4.9;ix,iy,iw,ih=7.08,1.7,5.05,4.18;crop=(0,0,0,.62)
  else:x,y,w,h=14+j*2.7,1.3,2.4,4.9;ix,iy,iw,ih=x+.25,y+.7,1.9,4.1;crop=(0,0,0,0)
  geom(s,x,y,w,h,PANEL,f'!!Panel{j}',MSO_SHAPE.ROUNDED_RECTANGLE)
  picture(s,asset+'.png',ix,iy,iw,ih,f'!!PanelImage{j}',crop=crop)
  if state=='overview':text(s,x+.2,y+.18,w-.4,.5,lab,26,FG,True,f'!!PanelTitle{j}');text(s,x+.2,y+.82,w-.4,.4,desc,13,MUTED,name=f'!!PanelCaption{j}')
  else:
   text(s,x+.22,y+.13,w-.4,.3,lab if isinstance(state,int) and j==state else '',12,GOLD,True,f'!!PanelTitle{j}')
  specs.append([x,y,w,h,ix,iy,iw,ih,*crop])
 return specs

SCENES=[
('hero','ПРОЕКТ','Саныч-6','Оператору. На месте работы.'),
('reveal','ПРОДУКТ','Рабочие инструменты.\nВ одном приложении.','Расчёты · инструкции · история'),
('goal','ЦЕЛЬ','Нужная информация.\nВ момент решения.','Упростить доступ оператора к проверенным\nрасчётам и рабочим материалам.'),
('tasks','ЗАДАЧИ','Три задачи.\nОдин рабочий инструмент.',''),
('overview','ВОЗМОЖНОСТИ','Выбрать задачу.\nПолучить опору.',''),
('manual','РУЧНОЙ ЗАМЕР','Старт. Объём.\nРезультат.','Секундомер и замер по интервалу.\nИстория на этом устройстве.'),
('macro','РУЧНОЙ ЗАМЕР','144',''),
('interval','ВРЕМЕННОЙ ИНТЕРВАЛ','Через полночь.\nБез ручного пересчёта.',''),
('ped','ОХЛАЖДЕНИЕ ПЭД','За числом —\nрабочая задача.','Исходные параметры → расчёт.\nПрименимость оценивает специалист.'),
('ped_detail','ОХЛАЖДЕНИЕ ПЭД','Учитывать условия\nработы двигателя.','Расчёт по исходным данным.\nБез вымышленных настроек оборудования.'),
('ramp','СТАНЦИИ УПРАВЛЕНИЯ','Разгон.\nСвой темп.','Параметры и инструкция\nдля выбранной станции.'),
('rich','СТАНЦИИ УПРАВЛЕНИЯ','РИЧ.\nСвоя последовательность.','Пошаговые материалы и фотографии.\nДействия контролирует персонал.'),
('vnr','РЕГЛАМЕНТ','207',''),
('vnr_macro','РЕГЛАМЕНТ','Найти.\nСохранить. Вернуться.','Поиск с подсветкой и переходами.\nЗакладки для быстрого возврата.'),
('tools','РАБОЧИЙ НАБОР','Расчёты + знания.','Инструменты для оператора и наставника.'),
('sources','ОСНОВА ПРОЕКТА','Понятно,\nна чём основано.',''),
('development','РАЗРАБОТКА','3 месяца',''),
('audience','МАСШТАБ','≈250',''),
('effect','ЭФФЕКТ','Пользу нужно\nизмерить в работе.',''),
('pilot','ПРЕДЛОЖЕНИЕ','Проверить.\nИзмерить. Решить.',''),
('closing','САНЫЧ-6','Знания рядом\nс решением.','Согласовать проверку содержания\nи ограниченный пилот.'),
('author','АВТОР','Из рабочих задач —\nв рабочий инструмент.','Автор: [ФИО]\n[Должность · номер цеха]'),
('appendix','МАТЕРИАЛЫ ДЛЯ ВОПРОСОВ','Расчёты и проверка',''),
('appendix_sources','МАТЕРИАЛЫ ДЛЯ ВОПРОСОВ','Источники и границы','')]
NOTES={
'hero':'Представиться устно. Имя и должность уточняются. Проект для обсуждения руководством. Не утверждать состоявшееся корпоративное внедрение.',
'reveal':'Показать инструмент в целом. Установка на Android и iPhone через PWA; реальный iPhone/Safari в этой среде не испытан.',
'goal':'Цель проекта — упростить доступ к проверенным расчётам и материалам в рабочем контексте. Приложение не управляет станцией.',
'manual':'По опыту автора в отдельные дни оператор выполняет 7–9 замеров. Не распространять эту частоту автоматически на 250 человек. Показан настоящий экран PWA с примером 100 л и 60 с.',
'macro':'Проверяемый математический пример: Q=86,4×Vлитры/tсекунды. 86,4×100/60=144 м³/сут. Это не фактическая добыча конкретной скважины.',
'interval':'Пример: начало 23:50, окончание 00:10 следующей даты — 20 минут. При 100 л Q=7,2 м³/сут. Начальная и конечная даты выбираются отдельно.',
'ped':'Важны исходные данные, единицы и применимость. Не представлять расчёт как гарантию предотвращения отказов.',
'ped_detail':'Условная схема, не инженерная симуляция. Никаких вымышленных потоков, температур или рекомендаций по конкретному оборудованию.',
'ramp':'Фотография станции КАСКАД-НТ из проекта. Значения на архивной фотографии не являются рекомендацией. Риск слишком быстрого разгона описан автором; конкретную причинность и допустимые настройки подтверждают технологи.',
'rich':'Не смешивать инструкции разных моделей. Приложение не блокирует ошибки и не переключает режимы оборудования. Неправильный порядок действий — рабочий сценарий автора для обсуждения с технологами.',
'vnr':'Доступны 207 страниц ВНР. Полный офлайн после предварительной загрузки. Отдельно проверять корпоративную допустимость распространения.',
'sources':'ВНР отдельно от документов ПБ и ОТ. Пять томов ПБ и ОТ названы автором; полнота интеграции и актуальность всех редакций не подтверждены. RosPump не интегрирован.',
'development':'Три календарных месяца, по данным автора. Прямые денежные расходы минимальны по его оценке; время не бесплатно. Внедрение, проверка и сопровождение требуют отдельной оценки.',
'audience':'Около 250 — оценка потенциальной аудитории автора, не число активных пользователей. Пилот предшествует масштабированию.',
'effect':'Не обещать предотвращённые ремонты и сохранённую добычу. Измерять время и корректность в сопоставимых заданиях, наличие материалов офлайн. Финансовые ставки и частота подтверждаются данными предприятия.',
'author':'Запасной слайд под точные ФИО, должность и портрет автора. Фото пока не получено. В основной показ до заполнения не включать.'}
for i,(kind,section,head,sub) in enumerate(SCENES):
 s=P.slides.add_slide(P.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=cc(BG)
 reserve=i>=21
 cx,cy,rr=10.1,3.7,3.12
 if kind=='hero':cx,cy,rr=10.2,3.8,3.2
 if kind=='reveal':cx,cy,rr=6.65,3.75,3.32
 if kind in ['goal','audience','development']:cx,cy,rr=3.25,3.65,2.7
 if kind=='interval':cx,cy,rr=10.2,3.75,2.9
 if kind in ['tasks','sources','effect','pilot']:cx,cy,rr=11.4,1.7,2.5
 if kind=='closing':cx,cy,rr=6.65,3.75,4.5
 ring(s,cx,cy,rr,i*21)
 state={'overview':'overview','manual':0,'macro':'manual_macro','ped':1,'ramp':2,'vnr':3,'vnr_macro':'vnr_macro'}.get(kind,None)
 ps=panels(s,state)
 if kind=='hero':
  # Editable layered typography and ring motif retained from the preferred v3.
  text(s,.75,1.65,8.3,1.8,'Саныч-6',88,FG,True,'!!Headline')
  text(s,.82,3.6,6.8,1.3,'Оператору.\nНа месте работы.',34,GOLD,True,'!!Subline')
  text(s,.84,5.7,7.6,.6,'Расчёты и рабочие материалы\nдля Android и iPhone',20,MUTED)
  glyph_photo(s,'6',8.35,1.65,3.4,4.65,'!!BigSix')
  phone(s,'home',9.65,1.1,2.42)
 elif kind=='reveal':
  text(s,.75,1.75,4.2,2.2,'Рабочие\nинструменты.',43,FG,True,'!!Headline');text(s,.8,4.6,3.8,1.2,'В одном\nприложении.',27,MUTED,name='!!Subline')
  phone(s,'home',5.3,.85,2.72)
  text(s,9,2.1,3.6,1.3,'Расчёты.',31,GOLD,True);text(s,9,3.2,3.8,1,'Инструкции.',31,FG,True);text(s,9,4.3,3.6,1,'История.',31,FG,True)
 elif kind=='goal':
  text(s,1.1,2.3,4.8,1.8,'01',132,GOLD,True,'!!Headline')
  text(s,6.6,1.35,6,2.25,head,38,FG,True,'GoalTitle');text(s,6.65,3.95,5.8,1.5,sub,23,MUTED,name='!!Subline')
  text(s,6.65,5.8,5.8,.5,'ЦЕЛЬ ПРОЕКТА',12,GOLD,True,spacing=90)
 elif kind=='tasks':
  title(s,head,size=45)
  for j,(num,h,b) in enumerate([('01','Объединить','Расчёты и справочные\nматериалы.'),('02','Упростить','Замеры и сохранение\nрезультатов.'),('03','Подготовить','Доступ на телефоне\nи материалы офлайн.')]):
   x=.8+j*4.15;geom(s,x,3.35,3.9,2.85,PANEL,f'!!TaskCard{j}',MSO_SHAPE.ROUNDED_RECTANGLE);text(s,x+.25,3.6,3.3,.55,num,30,GOLD,True);text(s,x+.25,4.4,3.3,.6,h,28,FG,True);text(s,x+.25,5.25,3.35,.9,b,20,MUTED)
 elif kind=='overview':
  text(s,.75,.95,11.9,1.0,'Четыре задачи. Один инструмент.',40,FG,True,'!!Headline')
 elif kind=='manual':
  title(s,head,sub,w=7.2,size=49,suby=3.4);points(s,['Секунды или минуты','Автоматическое сохранение','Возврат к текущему замеру'],y=5,w=7,size=20,step=.48)
 elif kind=='macro':
  text(s,.85,1.5,6,2.1,'144',147,GOLD,True,'!!Headline');text(s,1,3.85,5.5,.8,'м³/сут',41,FG,True,'!!Subline')
  text(s,1.05,5.1,5.6,1,'100 литров / 60 секунд\nМатематический пример',23,MUTED)
 elif kind=='interval':
  title(s,head,w=8,size=45)
  text(s,.85,3.5,8.0,1.2,'23:50 → 00:10',57,GOLD,True,'!!TimeWindow')
  text(s,.9,5.15,7.8,1,'20 минут · следующая дата\n100 л → 7,2 м³/сут',25,MUTED)
  # A clock with fixed ticks and changing geometry, built from editable shapes.
  for j in range(12):
   a=math.radians(j*30-90);geom(s,10.5+math.cos(a)*1.6-.025,4.25+math.sin(a)*1.6-.025,.05,.05,GOLD if j in [0,11] else LINE,f'ClockTick{j}',MSO_SHAPE.OVAL)
  geom(s,10.48,2.72,.04,1.55,GOLD,'ClockHand');geom(s,10.5,4.23,1,.04,FG,'ClockMinute',rot=15)
 elif kind=='ped':
  title(s,head,sub,w=7.4,size=47);points(s,['Параметры двигателя','Токи и необходимые исходные данные','Проверка результата специалистом'],y=5,w=7.1,size=19,step=.48)
 elif kind=='ped_detail':
  title(s,head,sub,w=7.6,size=44)
  # Neutral schematic; no fabricated technical setpoints.
  for x in [9.3,9.65,11.2,11.55]:geom(s,x,1.3,.035,4.9,LINE,'WellWall'+str(x))
  geom(s,10,3.1,.85,2.4,'213145','Motor',MSO_SHAPE.ROUNDED_RECTANGLE,line=GOLD)
  text(s,9.3,5.85,2.65,.5,'ПЭД',18,GOLD,True)
  text(s,.8,5.6,7.9,.6,'Условная схема · не инженерная симуляция',14,MUTED)
 elif kind=='ramp':
  title(s,head,sub,w=7.3,size=49)
  # Native picture strips show a single continuous photo, with exact source crop.
  for j in range(7):
   x=.85+j*.88;y=4.85+j*.035;picture(s,'station.jpg',x,y,.80,1.35,f'!!Shutter{j}',crop=(j/7,.319,1-(j+1)/7,.319))
  text(s,.85,6.37,7.1,.3,'Фото КАСКАД-НТ из проекта · значения на фото не являются рекомендацией',10,MUTED)
 elif kind=='rich':
  title(s,head,sub,w=8.1,size=37,suby=3.5)
  phone(s,'rich',9.45,1.1,2.4)
  for j,(a,b) in enumerate([('КАСКАД-НТ','Эталон ЧР'),('ЭЛЕКТОН','ОРИОН-01'),('ТРИОЛ (УМКА)','')]):
   text(s,.85,4.6+j*.55,3.5,.4,a,18,GOLD if j==0 else FG);text(s,4.6,4.6+j*.55,3.6,.4,b,18,FG)
  # Same seven image strips collapse to an upper border to reveal the station list.
  for j in range(7):picture(s,'station.jpg',.85+j*.88,6.45,.8,.08,f'!!Shutter{j}',crop=(j/7,.4,1-(j+1)/7,.4))
 elif kind=='vnr':
  text(s,.8,1.3,7,2.0,'207',149,GOLD,True,'!!Headline');text(s,.95,3.65,6.5,1.3,'страниц ВНР\nна телефоне',38,FG,True,'!!Subline');text(s,1,5.6,6.5,.7,'Офлайн после предварительной загрузки',19,MUTED)
 elif kind=='vnr_macro':
  title(s,head,sub,w=6.1,size=39,suby=3.5);points(s,['Совпадения и переходы','Ссылки внутри документа','Закладки на устройстве'],y=5.2,w=5.7,size=18,step=.45)
 elif kind=='tools':
  title(s,head,sub,w=7.8,size=49,suby=3)
  # Four persistent cards form an orbit, then collect into one workbench.
  for j,(a,x,y,w) in enumerate([('tap',9.4,1.0,1.9),('technologist',10.8,2.35,1.6),('manual',8.2,3.45,1.35)]):phone(s,a,x,y,w,name=f'!!Tool{j}')
  points(s,['Отпайка и расчётные разделы','Помощник по рабочим ситуациям','Материалы для обучения с наставником'],y=4.6,w=7.0,size=19,step=.58)
 elif kind=='sources':
  title(s,head,w=10,size=46)
  for j,(h,b) in enumerate([('Формулы','Исходный код Android.\nСохранение единиц\nи проверка примеров.'),('Регламент','Доступный документ ВНР.\nПоиск, ссылки\nи закладки.'),('Материалы','Предоставленные документы.\nРедакции и полноту\nнеобходимо сверить.')]):
   x=.8+j*4.15;geom(s,x,3.5,3.9,2.75,PANEL,f'SourceCard{j}',MSO_SHAPE.ROUNDED_RECTANGLE);text(s,x+.25,3.8,3.4,.6,h,27,GOLD,True);text(s,x+.25,4.7,3.4,1.3,b,20,MUTED)
 elif kind=='development':
  text(s,.95,1.65,11.6,1.9,'3 месяца',112,GOLD,True,'!!Headline');text(s,1.1,3.8,11,1,'разработки программы',42,FG,True,'!!Subline')
  text(s,1.15,5.2,10.8,.95,'Прямые денежные расходы, по оценке автора, минимальны.\nОсновной вклад — время.',23,MUTED)
 elif kind=='audience':
  text(s,.9,1.6,7.0,1.9,'≈250',129,GOLD,True,'!!Headline');text(s,1.05,3.75,6.8,1.3,'потенциальных\nпользователей',37,FG,True,'!!Subline')
  text(s,1.1,5.6,6.6,.6,'Оценка автора · пилот перед масштабированием',17,MUTED)
  for j in range(80):
   xx=8.55+(j%8)*.45;yy=1.3+(j//8)*.48;geom(s,xx,yy,.085,.085,GOLD if j<12 else LINE,f'AudienceDot{j}',MSO_SHAPE.OVAL)
 elif kind=='effect':
  title(s,head,w=10.5,size=47)
  for j,(h,b) in enumerate([('Время','Сопоставить типовые\nоперации до и после.'),('Корректность','Проверить расчёты\nи учебные сценарии.'),('Доступность','Проверить нужные\nматериалы без сети.')]):
   x=.85+j*4.15;geom(s,x,3.6,.075,.52,GOLD,f'MetricMark{j}');text(s,x+.23,3.56,3.6,.65,h,28,FG,True);text(s,x+.23,4.6,3.4,1.1,b,23,MUTED)
  text(s,.9,6.25,11.8,.35,'Денежный эффект — по данным пилота, без вымышленных цен ремонтов и потерь добычи.',14,MUTED)
 elif kind=='pilot':
  title(s,head,w=11,size=48)
  for j,(h,b) in enumerate([('Содержание','Сверка специалистами'),('Пилот','Ограниченная группа'),('Измерения','Единые задания'),('Решение','По результатам')]):
   x=.9+j*3.1;geom(s,x,4.03,.12,.12,GOLD,f'PilotNode{j}',MSO_SHAPE.OVAL)
   if j<3:geom(s,x+.12,4.08,2.98,.012,LINE,f'PilotLine{j}')
   text(s,x,4.55,2.9,.6,h,25,FG,True);text(s,x,5.4,2.9,.8,b,18,MUTED)
 elif kind=='closing':
  text(s,2,2.0,10,1.9,head,58,FG,True,'!!Headline');text(s,2.1,4.6,9.7,1.15,sub,28,GOLD,True,'!!Subline');text(s,2.15,6,9.6,.4,'САНЫЧ-6',16,MUTED,True,spacing=150)
 elif kind=='author':
  title(s,head,sub,w=8,size=44,suby=3.8);text(s,.8,5.9,8,.4,'ЗАПАСНОЙ СЛАЙД · ДАННЫЕ АВТОРА УТОЧНЯЮТСЯ',11,GOLD,True)
  # A reserved image frame, no invented portrait.
  geom(s,9.5,1.3,2.8,4.9,PANEL,'PortraitPlaceholder',MSO_SHAPE.ROUNDED_RECTANGLE,line=LINE)
  text(s,9.9,3.3,2,1.2,'Портрет\nавтора',23,MUTED)
 elif kind=='appendix':
  title(s,head,w=11,size=43)
  points(s,['Дебит: Q = 86,4 × V / t  (литры и секунды)','100 л / 60 с → 144 м³/сут','100 л / 1200 с → 7,2 м³/сут','Отчёт PWA v3: 58 тестов, 479 эталонных наборов, 6 проверок сборки'],y=3.3,w=11.6,size=22,step=.7)
  text(s,.85,6.3,11.6,.4,'Ранее сохранённые результаты; не означают испытания реального iPhone или Android-сборки.',13,MUTED)
 else:
  title(s,head,w=11,size=43)
  points(s,['ВНР: П1-05.01 М-0009 ЮЛ-099, версия 7; реквизиты сверить перед пилотом','ПБ и ОТ, пять томов: название со слов автора; полнота переноса не подтверждена','Учебные материалы RosPump и «Качество данных» — контекст, не интеграция','Приложение не управляет оборудованием и не заменяет действующие инструкции'],y=3.25,w=11.6,size=20,step=.75)
  text(s,.85,6.4,11.6,.3,'Реальный iPhone/Safari и воспроизведение Morph в Microsoft PowerPoint здесь не испытаны.',12,MUTED)
 chrome(s,i,section,reserve);morph(s,reserve=reserve)
 s.notes_slide.notes_text_frame.text=head+'\n\n'+NOTES.get(kind,'Показать смысл слайда коротко. Не зачитывать подписи. Рабочие материалы и применимость проверяются профильными специалистами.')+'\n\nПереход запускается щелчком. PDF статичен. Реальный Microsoft PowerPoint в этой среде не использован.'
 # Hide unfinished author and reference appendix from the main show.
 if reserve:s._element.set('show','0')
 META.append({'index':i+1,'kind':kind,'head':head,'panels':ps,'ring':[cx,cy,rr,i*21],'hidden':reserve})
# Interactive overview: cards open their sections inside the same PowerPoint file.
over=P.slides[4]
text(over,.8,1.78,11.6,.3,'Выберите раздел или продолжайте показ по порядку',12,MUTED,name='OverviewHint')
for j,target in enumerate([5,8,10,12]):
 for sh in over.shapes:
  if sh.name in [f'!!Panel{j}',f'!!PanelImage{j}',f'!!PanelTitle{j}',f'!!PanelCaption{j}']:sh.click_action.target_slide=P.slides[target]
for index in range(5,15):
 b=text(P.slides[index],10.35,.28,2.3,.25,'← Все инструменты',10,GOLD,name='!!BackToOverview')
 b.click_action.target_slide=over
for index,j,target in [(5,0,6),(6,0,5),(12,3,13),(13,3,12)]:
 for sh in P.slides[index].shapes:
  if sh.name==f'!!PanelImage{j}':sh.click_action.target_slide=P.slides[target]

P.save(R/'Sanich6_Premium_v4.pptx')
(R/'SCENES.json').write_text(json.dumps(META,ensure_ascii=False,indent=2))
(R/'TEXT.json').write_text(json.dumps(TEXT,ensure_ascii=False,indent=2))
print('Built',len(P.slides),'slides,',len(TEXT),'text objects')
